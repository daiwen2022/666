/** @type {import('tailwindcss').Config} */
module.exports = {
    content: [
        "./resources/**/*.blade.php",
        "./resources/**/*.js",
        "./resources/**/*.vue",
    ],
    theme: {
        screens: {
            'xl': {'max': '1200px'},
            'lg': {'max': '992px'},
            'md': {'max': '768px'},
            'sm': {'max': '679px'},
            'xsm': {'max': '576px'},
        },
        container: {
          padding: '150px',
          center: true
        },
        extend: {
            colors: {
              'main': '#d9ff45'
            },
            fontFamily: {
                'sans': ['Inter', 'Arial', 'sans-serif']
            }
        },
    },
    plugins: [require("@tailwindcss/forms")],
}
