<?php return array (
  'dash.articles' => 'App\\Http\\Livewire\\Dash\\Articles',
  'dash.categories' => 'App\\Http\\Livewire\\Dash\\Categories',
  'dash.files' => 'App\\Http\\Livewire\\Dash\\Files',
  'dash.transactions' => 'App\\Http\\Livewire\\Dash\\Transactions',
  'dash.users' => 'App\\Http\\Livewire\\Dash\\Users',
  'pay.payeer' => 'App\\Http\\Livewire\\Pay\\Payeer',
  'pay.payment' => 'App\\Http\\Livewire\\Pay\\Payment',
);