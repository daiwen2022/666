<?php

use App\Http\Controllers\Dash\ShowController;
use App\Http\Livewire\Pay\Payeer;
use App\Http\Livewire\Pay\Payment;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function ($category = null) {
    $categories = \App\Models\Categories::get();

    return view(
        'welcome',
        [
            'categories' => $categories
        ]
    );
})->name('welcome');

Route::get('/guarantee', function () {
    return view('guarantee');
})->name('guarantee');

Route::get('/howtobuy', function () {
    return view('howtobuy');
})->name('howtobuy');

Route::get('/transactions/my', function () {
    $user = \Illuminate\Support\Facades\Auth::user();

    $transactions = $user->transactions->sortByDesc('id');

    return view('mytrans', ['transactions' => $transactions]);
})->middleware('auth')->name('transactions.my');

Route::get('/categories/{category?}/view', function ($category = null) {
    $categories = \App\Models\Categories::get();

    if (!is_null($category)) {
        $categories = array();
        $category = \App\Models\Categories::find(intval($category));

        if (is_null($category) or $category->articles->isEmpty()) {
            return abort(404);
        }

        $categories[] = $category;
    }

    return view(
        'welcome',
        [
            'categories' => $categories
        ]
    );
});

Auth::routes();

Route::prefix('payment')->group(function () {
    Route::get('/create/{article}', [\App\Http\Controllers\PaymentController::class, 'show'])
        ->name('payment.show');

    Route::post('/create/', [\App\Http\Controllers\PaymentController::class, 'create'])
        ->name('payment.create');

    if (config('wave.payments.driver') == 'crystalpay') {
        Route::get('{uuid}', Payment::class)->name('payment.check');
    } elseif (config('wave.payments.driver') == 'payeer') {
        Route::get('{uuid}', Payeer::class)->name('payment.check');
    }

    Route::post('/cart/', [\App\Http\Controllers\PaymentController::class, 'addToCart'])
        ->middleware(['auth'])
        ->name('payment.cart.add');

    Route::get('/cart/remove/{cart}', function ($cart) {
        $object = \App\Models\Cart::find($cart);

        if (!is_null($object)) {
            $object->delete();
        }

        return redirect()->route('welcome');
    })->middleware(['auth'])->name('payment.cart.remove');
});

Route::prefix('dash')->middleware(['auth', 'role:admin'])->group(function () {
    Route::get('/', [ShowController::class, 'show'])->name('dash.show');
    Route::get('/articles', [ShowController::class, 'show'])->name('dash.show.articles');
    Route::get('/transactions', [ShowController::class, 'show'])->name('dash.show.transactions');
    Route::get('/categories', [ShowController::class, 'show'])->name('dash.show.categories');
    Route::get('/files', [ShowController::class, 'show'])->name('dash.show.files');
});
