<?php

namespace App\Http\Livewire\Dash;

use Livewire\Component;

class Categories extends Component
{

    public $search = "";
    public $showEditModal = false;
    public \App\Models\Categories $editing;

    protected $rules = [
        'editing.title' => 'required|string',
    ];

    public function edit(\App\Models\Categories $categoriy)
    {
        $this->editing = $categoriy;
        $this->showEditModal = true;
    }

    public function delete(\App\Models\Categories $category)
    {
        $category->delete();
        $this->showEditModal = false;
        $this->showCreateModal = false;
    }

    public function save() {

        $this->validate();
        $this->editing->save();
        $this->showEditModal = false;
    }

    public function render()
    {
        return view('livewire.dash.categories', [
            'categories' => \App\Models\Categories::search('title', $this->search)->get(),
            'categoriesCount' => \App\Models\Categories::get()->count(),
            'search' => $this->search,
        ]);
    }
}
