<?php

namespace App\Http\Livewire\Dash;

use App\Models\Accounts;
use Livewire\Component;

class Files extends Component
{

    public $search = "";
    public $showEditModal = false;
    public $showAddDataModal = false;
    public \App\Models\Accounts $editing;

    public $newdata = "";

    protected $rules = [
        'editing.file' => 'required|string',
    ];

    public function edit(\App\Models\Accounts $categoriy)
    {
        $this->editing = $categoriy;
        $this->showEditModal = true;
    }

    public function addData(Accounts $account)
    {
        $this->editing = $account;
        $this->showAddDataModal = true;
    }

    public function saveData()
    {
        $this->validate([
            'newdata' => 'required|string',
        ]);

        file_put_contents('files/' . $this->editing->file, PHP_EOL . $this->newdata, FILE_APPEND | LOCK_EX);

        $accounts = $this->editing->articles;

        if (!$accounts->isEmpty()) {
            foreach ($accounts as $account) {
                $account->count = strval(intval($account->count) + 1);
                $account->save();
            }
        }

        $this->newdata = "";
        $this->showAddDataModal = false;
    }

    public function delete(\App\Models\Accounts $category)
    {
        $category->delete();
        $this->showEditModal = false;
        $this->showCreateModal = false;
    }

    public function save()
    {
        $this->validate();
        $this->editing->save();
        $this->showEditModal = false;
    }

    public function render()
    {
        return view('livewire.dash.files', [
            'files' => \App\Models\Accounts::search('file', $this->search)->get(),
            'filesCount' => \App\Models\Accounts::get()->count(),
            'search' => $this->search,
        ]);
    }
}
