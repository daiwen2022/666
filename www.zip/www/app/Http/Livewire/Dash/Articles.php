<?php

namespace App\Http\Livewire\Dash;

use App\Models\User;
use Livewire\Component;

class Articles extends Component
{

    public $search = '';
    public $showEditModal = false;
    public \App\Models\Articles $editing;

    protected $rules = [
        'editing.title' => 'required|string',
        'editing.description' => 'required|string',
        'editing.price' => 'required|integer',
        'editing.count' => 'required|integer',
        'editing.categories_id' => 'required|integer',
        'editing.file_id' => 'required|integer'
    ];

    public function edit(\App\Models\Articles $article)
    {
        $this->editing = $article;
        $this->showEditModal = true;
    }

    public function delete(\App\Models\Articles $article)
    {
        $article->delete();
        $this->showEditModal = false;
        $this->showCreateModal = false;
    }

    public function save() {

        $this->validate();
        $this->editing->save();
        $this->showEditModal = false;
    }

    public function render()
    {
        return view('livewire.dash.articles', [
            'articles' => \App\Models\Articles::search('title', $this->search)->get(),
            'articlesCount' => \App\Models\Articles::get()->count(),
            'search' => $this->search,
        ]);
    }
}
