<?php

namespace App\Http\Livewire\Dash;

use App\Models\User;
use Livewire\Component;
use Livewire\WithPagination;
use Illuminate\Pagination\Paginator;

class Users extends Component
{

    use WithPagination;

    public $search = '';
    public $showEditModal = false;
    public $showCreateModal = false;
    public User $editing;

    protected $rules = [
        'editing.name' => 'required|string',
        'editing.email' => 'required|email'
    ];

    public function edit(User $user)
    {
        $this->editing = $user;
        $this->showEditModal = true;
    }

    public function delete(User $user)
    {
        $user->delete();
        $this->showEditModal = false;
        $this->showCreateModal = false;
    }

    public function save() {

        $this->validate();
        $this->editing->save();
        $this->showEditModal = false;
    }

    public function toggleAdmin() {

        if ($this->editing->isAdmin()) {
            $this->editing->removeRole('admin');
        } else {
            $this->editing->assignRole('admin');
        }

        $this->showEditModal = false;

    }

    public function render()
    {
        return view('livewire.dash.users',
            [
                'users' => User::search('name', $this->search)->get(),
                'usersCount' => User::get()->count(),
                'search' => $this->search,
            ]);
    }
}
