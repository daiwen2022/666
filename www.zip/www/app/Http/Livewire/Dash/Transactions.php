<?php

namespace App\Http\Livewire\Dash;

use Livewire\Component;

class Transactions extends Component
{

    public $search = "";
    public $showEditModal = false;
    public \App\Models\Transactions $editing;

    protected $rules = [
        'editing.title' => 'required|string',
        'editing.status' => 'required|string',
        'editing.created_at' => 'required|date'
    ];

    public function edit(\App\Models\Transactions $transaction)
    {
        $this->editing = $transaction;
        $this->showEditModal = true;
    }

    public function delete(\App\Models\Transactions $transaction)
    {
        $transaction->delete();
        $this->showEditModal = false;
        $this->showCreateModal = false;
    }

    public function save() {

        $this->validate();
        $this->editing->save();
        $this->showEditModal = false;
    }

    public function render()
    {
        return view('livewire.dash.transactions',
            [
                'transactions' => \App\Models\Transactions::search('title', $this->search)->get(),
                'transactionsCount' => \App\Models\Transactions::get()->count(),
                'search' => $this->search,
            ]);
    }
}
