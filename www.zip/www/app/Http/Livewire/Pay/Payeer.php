<?php

namespace App\Http\Livewire\Pay;

use App\Mail\SendPaymentMail;
use App\Models\Transactions;
use Illuminate\Support\Facades\Mail;
use Livewire\Component;

class Payeer extends Component
{

    public Transactions $transaction;
    public $payed = false;
    public $gettxid = true;

    public $txid = "";

    public $accounts = [];

    public function mount($uuid)
    {
        $tr = Transactions::where('transaction_uuid', $uuid)->first();

        abort_if(is_null($tr), 404);

        if ($tr->status == 'failed') {
            return redirect()->route('welcome');
        }

        $this->transaction = $tr;
    }

    public function check()
    {
        $this->gettxid = true;
    }

    public function checkstart()
    {
        $validatedData = $this->validate([
            'txid' => 'required|string',
        ]);

        $fullNode = new \IEXBase\TronAPI\Provider\HttpProvider('https://api.trongrid.io');
        $solidityNode = new \IEXBase\TronAPI\Provider\HttpProvider('https://api.trongrid.io');
        $eventServer = new \IEXBase\TronAPI\Provider\HttpProvider('https://api.trongrid.io');

        $tron = new \IEXBase\TronAPI\Tron($fullNode, $solidityNode, $eventServer);

        $tron->setAddress(env('TRON_ADDRESS'));
        $tron->setPrivateKey(env('TRON_PRIVATE'));

        try {
            $trans = $tron->getTransaction($this->txid);
            $status = $trans['ret'][0]['contractRet'];

            if ($status == "SUCCESS") {
                $value = $trans['raw_data']['contract'][0]['parameter']['value']['amount'];

                $this->transaction->status = 'success';
                $this->transaction->save();
            }
        } catch (\Exception $e) {
            $this->txid = "";
        }

        return redirect()->route('payment.check', $this->transaction->getUUID());
    }

    public function testpay()
    {
        $this->transaction->status = 'success';
        $this->transaction->save();

        return redirect()->route('payment.check', $this->transaction->getUUID());
    }

    public function render()
    {
        $this->payed = $this->transaction->status == 'success';

        if ($this->payed) {
            if ($this->transaction->accounts == null) {
                $totalAccounts = file(
                    asset('files/' . $this->transaction->article->accounts->file),
                    FILE_IGNORE_NEW_LINES
                );
                $toTransactionDB = "";

                for ($i = 0; $i < $this->transaction->count; $i++) {
                    $ac = $totalAccounts[array_rand($totalAccounts)];
                    $this->accounts[] = $ac;
                    $toTransactionDB .= $ac . ",";
                }


                $acAnotherFile = file_get_contents(asset('files/' . $this->transaction->article->accounts->file));
                foreach ($this->accounts as $acc) {
                    $acAnotherFile = str_replace($acc, '', $acAnotherFile);
                }


                file_put_contents(
                    'files/' . $this->transaction->article->accounts->file,
                    preg_replace(
                        '~[\r\n]+~',
                        "\r\n",
                        trim($acAnotherFile)
                    )
                );

                $this->transaction->accounts = mb_substr($toTransactionDB, 0, -1);
                $this->transaction->article->decrement('count', $this->transaction->count);
                $this->transaction->save();

                Mail::to($this->transaction->email)->send(new SendPaymentMail($this->transaction));
            } else {
                $this->accounts = explode(',', $this->transaction->accounts);
            }
        }

        return view('livewire.pay.payeer');
    }
}
