<?php

namespace App\Http\Livewire\Pay;

use App\Mail\SendPaymentMail;
use App\Models\Articles;
use App\Models\Transactions;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Livewire\Component;
use App\CrystalPay\CrystalHandler;

class Payment extends Component
{
    public Transactions $transaction;
    public $payed = false;
    public $url = '';
    public $checkedState = false;
    public $accounts = [];
    protected CrystalHandler $crystalpay;

    public function mount($uuid) {
        $tr = Transactions::where('transaction_uuid', $uuid)->first();

        abort_if(is_null($tr), 404);

        if ($tr->status == 'failed') {
            return redirect()->route('welcome');
        }

        $this->transaction = $tr;

        $this->crystalpay = new CrystalHandler(env('CRYSTALPAY_SECRET'), env('CRYSTALPAY_LOGIN'), $this->transaction, 120);
    }

    public function check() {
        $this->checkedState = true;
        $this->crystalpay = new CrystalHandler(env('CRYSTALPAY_SECRET'), env('CRYSTALPAY_LOGIN'), $this->transaction, 120);
        $this->payed = $this->crystalpay->checkInvoice($this->transaction->i);
        $this->checkedState = false;
    }

    public function render()
    {

        if (is_null($this->transaction->i)) {
            $this->url = $this->crystalpay->createInvoice(intval($this->transaction->amount));
        } else {
            $this->payed = $this->crystalpay->checkInvoice($this->transaction->i);
            $this->url = 'https://pay.crystalpay.ru/?i=' . $this->transaction->i;
        }

        if ($this->payed) {

            if ($this->transaction->accounts == null) {
                $totalAccounts = file(asset('files/' . $this->transaction->article->accounts->file), FILE_IGNORE_NEW_LINES);
                $toTransactionDB = "";

                for ($i = 0; $i < $this->transaction->count; $i++) {
                    $ac = $totalAccounts[array_rand($totalAccounts)];
                    $this->accounts[] = $ac;
                    $toTransactionDB .= $ac .  ",";
                }


                $acAnotherFile = file_get_contents(asset('files/' . $this->transaction->article->accounts->file));
                foreach ($this->accounts as $acc) {
                    $acAnotherFile = str_replace($acc, '', $acAnotherFile);
                }


                file_put_contents('files/' . $this->transaction->article->accounts->file, preg_replace(
                    '~[\r\n]+~',
                    "\r\n",
                    trim($acAnotherFile)
                ));

                $this->transaction->accounts = mb_substr($toTransactionDB, 0, -1);
                $this->transaction->article->decrement('count', $this->transaction->count);
                $this->transaction->save();

                Mail::to($this->transaction->email)->send(new SendPaymentMail($this->transaction));
            } else {
                $this->accounts = explode(',', $this->transaction->accounts);
            }

        }

        return view('livewire.pay.payment');
    }
}
