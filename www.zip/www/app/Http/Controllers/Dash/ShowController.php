<?php

namespace App\Http\Controllers\Dash;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ShowController extends Controller
{
    public function show(Request $request) {

        return view('admin.show', ['request' => $request]);

    }
}
