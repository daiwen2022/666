<?php

namespace App\Http\Controllers;

use App\Models\Articles;
use App\Models\Cart;
use App\Models\Transactions;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    public function show($article)
    {
        $art = Articles::find(intval($article));

        abort_if(is_null($art), 404);

        if ($art->count == 0) {
            return redirect()->route('welcome');
        }

        return view('pay.payment', ['article' => $art]);
    }

    public function create(Request $request)
    {
        $request->validate([
            'count' => ['required', 'integer'],
            'email' => ['email', 'required'],
            'articleid' => ['required', 'integer']
        ]);

        $article = Articles::find(intval($request->articleid));

        if (intval($request->count) > intval($article->count)) {
            return $this->show($request->articleid);
        }

        $user = null;

        if (\Auth::check()) {
            $user = intval(\Auth::user()->id);

            if ($request->cart) {
                $cartObject = new Cart();
                $cartObject->user_id = \Auth::user()->getAuthIdentifier();
                $cartObject->article_id = $article->id;
                $cartObject->count = $request->count;
                $cartObject->save();
                return redirect()->route('welcome');
            }
        }

        $transaction = Transactions::create([
            'title' => $article->title,
            'email' => $request->email,
            'count' => $request->count,
            'status' => 'processing',
            'amount' => strval($article->price * intval($request->count)),
            'user_id' => $user,
            'article_id' => $article->id
        ]);

        $transaction = Transactions::where('transaction_uuid', $transaction->getUUID())->first();

        return redirect()->route('payment.check', $transaction->transaction_uuid);
    }
}
