<?php

namespace App\CrystalPay;

use App\Models\Transactions;
use Illuminate\Support\Facades\Http;

class CrystalHandler
{

    protected $secret;
    protected $login;
    protected $lifetime = 1440;
    protected $requestURL = 'https://api.crystalpay.ru/v1/';

    protected Transactions $transaction;

    protected $callback = '';
    protected $redirect = '';

    public function __construct($secret, $login, Transactions $transaction, $lifetime = null)
    {
        $this->secret = $secret;
        $this->login = $login;
        $this->transaction = $transaction;

        if (!is_null($lifetime)) {
            $this->lifetime = $lifetime;
        }

        $this->requestURL .= '?s=' . $this->secret . "&n=".$this->login;
    }

    public function createInvoice($amount) {

        $uri = $this->requestURL .= '&o=invoice-create&amount=' . strval($amount) . '&extra=' . $this->transaction->getUUID() . '&currency=USD' . '&lifetime=' . $this->lifetime
            . '&redirect=' . env('APP_URL') . '/payment/' . $this->transaction->getUUID();

        $request = Http::get($uri);
        $request = $request->json();

        $this->transaction->updateInvoiceID($request['id']);

        return $request['url'];
    }

    public function checkInvoice($id) {
        $uri = $this->requestURL .= '&o=invoice-check&i=' . strval($id);

        $request = Http::get($uri);
        $request = $request->json();

        if ($request['state'] == 'payed') {
            $this->transaction->status = 'success';
            $this->transaction->save();
            return true;
        }

        if ($request['state'] == 'notpayed') {
            $this->transaction->status = 'failed';
            $this->transaction->save();
            return false;
        }

        return false;
    }

}
