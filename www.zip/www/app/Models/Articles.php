<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Articles extends Model
{
    use HasFactory;

    protected $fillable = [
        'id', 'title', 'description', 'price', 'count', 'created_at'
    ];

    public function category() {
        return $this->belongsTo(Categories::class, 'categories_id');
    }

    public function transactions() {
        return $this->hasMany(Transactions::class);
    }

    public function accounts() {
        return $this->belongsTo(Accounts::class, 'file_id');
    }
}
