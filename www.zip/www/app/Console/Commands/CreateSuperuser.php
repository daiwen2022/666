<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;

class CreateSuperuser extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'wave:create-admin {user}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Update user to admin by his ID';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $user = User::find(intval($this->argument('user')));

        if (is_null($user)) {
            $this->error('User not found.');
            return Command::FAILURE;
        }

        $this->info('Updating ' . $user->name . '...');
        $user->assignRole('admin');

        $this->info('User updated!');

        return Command::SUCCESS;
    }
}
