<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class Setup extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'wave:setup';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'First solution setup';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {

        $this->info('Migrating tables...');
        $this->call('migrate');

        $this->info('Creating admin role...');
        $this->call('permission:create-role', ['name' => 'admin']);

        return Command::SUCCESS;
    }
}
