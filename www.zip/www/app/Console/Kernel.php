<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * Define the application's command schedule.
     *
     * @param \Illuminate\Console\Scheduling\Schedule $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        $schedule->call(function () {
            $transactions = Transactions::get();

            foreach ($transactions as $transaction) {
                $created = new Carbon($transaction->created_at);
                $now = Carbon::now();
                $diff = $created->diff($now)->h;

                if ($diff >= 1 && $transaction->status == 'processing') {
                    $transaction->status = 'failed';
                    $transaction->save();
                }
            }
        })->hourly();
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__ . '/Commands');

        require base_path('routes/console.php');
    }
}
