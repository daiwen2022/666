<x-app-layout>

    <div class="bgs__video w-auto h-auto overflow-hidden fixed z-[-999] left-0 right-0 top-0 bottom-0" style="opacity: 1;">
        <video id="bgvideo" class="bgvideo w-auto h-auto min-w-[100%] min-h-[100%] border-[0] opacity-[0.3]" poster="https://i.imgur.com/ODpemDt.jpg" loop="" autoplay="" muted="" playsinline="">
            <source src="https://bsteam.clan.su/filesbg/animatebg.mp4" type="video/mp4">
        </video>
    </div>

    <header>
        <x-navigation />
    </header>

    <div class="container mt-12">
        <div class="flex justify-center">
            <div class="infopage__igr0k">
                <p style="color: white;"><span style="color: rgb(255, 255, 255);"><span style="font-size: 24px; font-weight: bold;">如何在YUN123.ORG上购买产品？</span>
	</span>
                </p>
                <p style="color: white;"><span style="color: rgb(255, 255, 255);">要购买我们的任何产品，您需要单击“购买”按钮.<br><br>在出现的窗口中：<br>
	</span>
                </p>
                <p style="color: white;"><span style="color: rgb(255, 255, 255);">1. 输入您的邮箱地址，货物将送达那里
	</span>
                </p>
                <p style="color: white;"><span style="color: rgb(255, 255, 255);">2.输入所需的产品数量
	</span>
                </p>
                <p style="color: white;"><span style="color: rgb(255, 255, 255);">3.选择方便的支付方式
	</span>
                </p>
                <p style="color: white;"><span style="color: rgb(255, 255, 255);">4. 单击“继续付款”按钮.<br><br>
	</span>
                </p>
                <p style="color: white;"><span style="color: rgb(255, 255, 255);">您将看到一个窗口，其中包含订单金额、商品付款详情和备注. 重要的！
	</span>
                </p>
                <p style="color: white;"><span style="color: rgb(255, 255, 255);">付款须知输入 #<br><br>
	</span>
                </p>
                <p style="color: white;"><span style="color: rgb(255, 255, 255);">然后转到您的支付系统并输入相应的字段.
	</span>
                </p>
                <p style="color: white;"><strong><span style="color: rgb(255, 255, 255);">付款后，点击“检查付款”按钮".</span></strong>
                </p>
            </div>        </div>
    </div>
</x-app-layout>
