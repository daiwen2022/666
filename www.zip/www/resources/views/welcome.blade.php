<x-app-layout>

    <div class="bgs__video w-auto h-[100vh] overflow-hidden fixed z-[-999] left-0 right-0 top-0 bottom-0"
         style="opacity: 1;">
        <video id="bgvideo" class="bgvideo w-auto h-[100vh] border-[0] opacity-[0.3]"
               poster="https://i.imgur.com/ODpemDt.jpg" loop="" autoplay="" muted="" playsinline="">
            <source src="https://bsteam.clan.su/filesbg/animatebg.mp4" type="video/mp4">
        </video>
    </div>

    <x-slot name="title">WAVESTORE | 云商城</x-slot>

    <header>
        <x-navigation/>
    </header>

    <main class="mt-[70px] mb-[20px]">
        <div class="hero">
            <div class="container text-center">

                <div class="flex justify-center mb-[50px]">
                    <img src="{{ asset('favicon.svg') }}" class="h-28" alt="favicon">
                </div>

                <h1 class="text-slate-200 font-semibold text-5xl md:text-2xl">推特账号和电报账号和其他热门应用</h1>
                <p class="text-slate-400 mt-4">云商城是卖各种产品的热门帐户商店</p>

            </div>
        </div>

        <div class="container mt-12">
            <section class="flex items-center justify-center gap-12">
                <a href=""https://t.me/ZH5566"
                   class="flex items-center space-x-6 bg-slate-800 py-2 pr-6 pl-5 rounded-xl duration-300 border border-slate-800 hover:bg-transparent hover:border-slate-600">
                    <img src="https://ruju.ru/bitrix/templates/aspro_next/images/telegram-logo-2.png"
                         class="h-16 lg:h-12 md:h-8 rounded-full" alt="">
                    <div>
                        <h1 class="font-medium text-slate-200 text-[18px] lg:text-[14px] md:text-[12px]">电报.
                            客服</h1>
                        <p class="text-slate-400 text-[17px] lg:hidden">关于店铺的问题</p>
                    </div>
                </a>

                <a href="t.me/"
                   class="flex items-center space-x-6 bg-slate-800 py-2 pr-6 pl-5 rounded-xl duration-300 border border-slate-800 hover:bg-transparent hover:border-slate-600">
                    <img src="https://ruju.ru/bitrix/templates/aspro_next/images/telegram-logo-2.png"
                         class="h-16 lg:h-12 md:h-8 rounded-full" alt="">
                    <div>
                        <h1 class="font-medium text-slate-200 text-[18px] lg:text-[14px] md:text-[12px]">电报
                            频道</h1>
                        <p class="text-slate-400 text-[17px] lg:hidden">促销和折扣</p>
                    </div>
                </a>
            </section>
        </div>

        @if($categories)
            <div class="container mt-12">
                <div class="nav nav-cat list-none text-center">
                    <div class="list-group space-x-5">

                        @foreach($categories as $category)
                            <a href="/categories/{{$category->id}}/view"
                               class="px-12 lg:px-8 md:px-4 sm:px-2 xsm:px-1 py-3 rounded-xl bg-slate-800 text-slate-300 duration-300 hover:bg-main hover:text-slate-800">
                                {{ $category->title }}
                            </a>
                        @endforeach

                    </div>
                </div>

                <div class="mt-10 w-full">
                    @foreach($categories as $category)
                        @if (!$category->articles->isEmpty())
                            <div class="h-[0.5px] bg-slate-600 mb-5"></div>
                            @foreach($category->articles as $article)
                                <a href="{{ route('payment.show', $article->id) }}"
                                   class="py-4 px-8 rounded-xl text-slate-200 bg-slate-800 w-full flex items-center w-full mb-4">
                                    <div class="flex justify-between items-center w-full">
                                        <section>
                                            <h1>{{ $article->title }}</h1>
                                            <h1 class="text-[13px] text-slate-400">{{ $article->price }} $ /
                                                1</h1>
                                            <h1 class="text-[13px] text-slate-400">
                                                Count: {{ $article->count }}</h1>
                                        </section>
                                        <section>
                                        <span
                                            class="border border-main py-1 px-4 rounded-xl">{{ $article->category->title }}</span>
                                        </section>
                                    </div>
                                </a>
                            @endforeach
                            <div class="h-[0.5px] bg-slate-600"></div>
                        @endif
                    @endforeach
                </div>
            </div>
    @endif
    {{--        @if($categories)--}}
    {{--            <div class="container mt-12">--}}
    {{--                <div class="container">--}}
    {{--                    <div class="container">--}}
    {{--                        <div class="flex justify-start gap-x-12">--}}
    {{--                            <div class="flex-none">--}}
    {{--                                <ul class="space-y-6">--}}
    {{--                                    @foreach($categories as $category)--}}
    {{--                                        <li>--}}
    {{--                                            <a href="/categories/{{$category->id}}/view"--}}
    {{--                                               class="py-2 px-7 flex justify-center text-center bg-slate-800 text-slate-200 rounded-xl duration-300 hover:text-slate-800 hover:bg-main">--}}
    {{--                                                {{ $category->title }}--}}
    {{--                                            </a>--}}
    {{--                                        </li>--}}
    {{--                                    @endforeach--}}
    {{--                                </ul>--}}
    {{--                            </div>--}}
    {{--                            <div class="w-full space-y-3">--}}
    {{--                                @foreach($categories as $category)--}}
    {{--                                    @foreach($category->articles as $article)--}}
    {{--                                        <div class="w-full">--}}
    {{--                                            <a href="{{ route('payment.show', $article->id) }}"--}}
    {{--                                               class="py-4 px-8 rounded-xl text-slate-200 bg-slate-800 w-full flex items-center w-full">--}}
    {{--                                                <div class="flex justify-between items-center w-full">--}}
    {{--                                                    <section>--}}
    {{--                                                        <h1>{{ $article->title }}</h1>--}}
    {{--                                                        <h1 class="text-[13px] text-slate-400">{{ $article->price }} $ /--}}
    {{--                                                            1</h1>--}}
    {{--                                                        <h1 class="text-[13px] text-slate-400">--}}
    {{--                                                            Count: {{ $article->count }}</h1>--}}
    {{--                                                    </section>--}}
    {{--                                                    <section>--}}
    {{--                                                        <span--}}
    {{--                                                            class="border border-main py-1 px-4 rounded-xl">{{ $article->category->title }}</span>--}}
    {{--                                                    </section>--}}
    {{--                                                </div>--}}
    {{--                                            </a>--}}
    {{--                                        </div>--}}
    {{--                                    @endforeach--}}
    {{--                                @endforeach--}}
    {{--                            </div>--}}
    {{--                        </div>--}}
    {{--                    </div>--}}
    {{--                </div>--}}
    {{--            </div>--}}
    {{--    @endif--}}
</x-app-layout>
