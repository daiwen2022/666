<x-app-layout>

    <div class="bgs__video w-auto h-auto overflow-hidden fixed z-[-999] left-0 right-0 top-0 bottom-0"
         style="opacity: 1;">
        <video id="bgvideo" class="bgvideo w-auto h-auto min-w-[100%] min-h-[100%] border-[0] opacity-[0.3]"
               poster="https://i.imgur.com/ODpemDt.jpg" loop="" autoplay="" muted="" playsinline="">
            <source src="https://bsteam.clan.su/filesbg/animatebg.mp4" type="video/mp4">
        </video>
    </div>

    <x-slot name="title">WAVESTORE | 帐号商店</x-slot>

    <header>
        <x-navigation/>
    </header>

    <main class="mt-[70px] mb-[20px]">
        <div class="hero">
            <div class="container text-center">

                <div class="flex justify-center mb-[50px]">
                    <img src="{{ asset('favicon.svg') }}" class="h-28" alt="favicon">
                </div>

                <h1 class="text-slate-200 font-semibold text-5xl">推特账号和电报账号和其他热门应用</h1>
                <p class="text-slate-400 mt-4">云商城是卖各种产品的热门帐户商店</p>

            </div>
        </div>

        <div class="container mt-12">
            <section class="flex items-center justify-center gap-12">
                <a href="t.me/"
                   class="flex items-center space-x-6 bg-slate-800 py-2 pr-6 pl-5 rounded-xl duration-300 border border-slate-800 hover:bg-transparent hover:border-slate-600">
                    <img src="https://ruju.ru/bitrix/templates/aspro_next/images/telegram-logo-2.png"
                         class="h-16 rounded-full" alt="">
                    <div>
                        <h1 class="font-medium text-slate-200 text-[18px]">电报. 客服</h1>
                        <p class="text-slate-400 text-[17px]">关于订单的问题</p>
                    </div>
                </a>

                <a href="t.me/"
                   class="flex items-center space-x-6 bg-slate-800 py-2 pr-6 pl-5 rounded-xl duration-300 border border-slate-800 hover:bg-transparent hover:border-slate-600">
                    <img src="https://ruju.ru/bitrix/templates/aspro_next/images/telegram-logo-2.png"
                         class="h-16 rounded-full" alt="">
                    <div>
                        <h1 class="font-medium text-slate-200 text-[18px]">电报频道</h1>
                        <p class="text-slate-400 text-[17px]">促销和折扣</p>
                    </div>
                </a>
            </section>
        </div>

        @if($transactions)
            <div class="container mt-12">
                <div class="container">
                    <div class="container">
                        <div class="w-full space-y-3">
                            @foreach($transactions as $transaction)
                                <div class="w-full">
                                    <a href="{{ route('payment.check', $transaction->getUUID()) }}"
                                       class="py-4 px-8 rounded-xl text-slate-200 bg-slate-800 w-full flex items-center w-full">
                                        <div class="flex justify-between items-center w-full">
                                            <section>
                                                <h1>{{ $transaction->title }}</h1>
                                                <h1 class="text-[13px] text-slate-400">{{ $transaction->amount }} $ /
                                                    1</h1>
                                                <h1 class="text-[13px] text-slate-400">
                                                    Count: {{ $transaction->count }}</h1>
                                            </section>
                                            <section class="space-x-2">
                                                @if ($transaction->status == 'success')
                                                    <span
                                                        class="border border-green-500 py-1 px-4 rounded-xl">PAID</span>
                                                @elseif($transaction->status == 'failed')
                                                    <span
                                                        class="border border-red-500 py-1 px-4 rounded-xl">FALIED</span>
                                                @elseif($transaction->status == 'processing')
                                                    <span class="border border-slate-700 py-1 px-4 rounded-xl">PROCESSING</span>
                                                @endif
                                            </section>
                                        </div>
                                    </a>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
            </div>
    @endif
</x-app-layout>
