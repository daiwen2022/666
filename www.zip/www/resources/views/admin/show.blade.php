<x-app-layout>

    <x-slot name="title">Dashboard</x-slot>

    <div class="relative flex min-h-screen">

        <div class="bg-slate-800 text-slate-300 py-8 px-5 text-center">
            <div class="flex justify-center">
                <a href="{{ route('dash.show') }}" class="">
                    <img src="{{ asset('favicon.svg') }}" alt="favicon" class="h-20 border-b border-slate-500 pb-6">
                </a>
            </div>

            <div class="flex justify-center">
                <ul class="mt-6 space-y-5">
                    <li class="flex">
                        <x-sidenav-link href="{{ route('dash.show') }}" :active="request()->routeIs('dash.show')">
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-users" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                <circle cx="9" cy="7" r="4"></circle>
                                <path d="M3 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2"></path>
                                <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                                <path d="M21 21v-2a4 4 0 0 0 -3 -3.85"></path>
                            </svg>
                        </x-sidenav-link>
                    </li>

                    <li class="flex">
                        <x-sidenav-link href="{{ route('dash.show.transactions') }}" :active="request()->routeIs('dash.show.transactions')">
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-receipt" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                <path d="M5 21v-16a2 2 0 0 1 2 -2h10a2 2 0 0 1 2 2v16l-3 -2l-2 2l-2 -2l-2 2l-2 -2l-3 2m4 -14h6m-6 4h6m-2 4h2"></path>
                            </svg>
                        </x-sidenav-link>
                    </li>

                    <li class="flex">
                        <x-sidenav-link href="{{ route('dash.show.articles') }}" :active="request()->routeIs('dash.show.articles')">
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-garden-cart" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                <circle cx="17.5" cy="17.5" r="2.5"></circle>
                                <path d="M6 8v11a1 1 0 0 0 1.806 .591l3.694 -5.091v.055"></path>
                                <path d="M6 8h15l-3.5 7l-7.1 -.747a4 4 0 0 1 -3.296 -2.493l-2.853 -7.13a1 1 0 0 0 -.928 -.63h-1.323"></path>
                            </svg>
                        </x-sidenav-link>
                    </li>

                    <li class="flex">
                        <x-sidenav-link href="{{ route('dash.show.categories') }}" :active="request()->routeIs('dash.show.categories')">
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-category" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                <path d="M4 4h6v6h-6z"></path>
                                <path d="M14 4h6v6h-6z"></path>
                                <path d="M4 14h6v6h-6z"></path>
                                <circle cx="17" cy="17" r="3"></circle>
                            </svg>
                        </x-sidenav-link>
                    </li>

                    <li class="flex">
                        <x-sidenav-link href="{{ route('dash.show.files') }}" :active="request()->routeIs('dash.show.files')">
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-files" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                <path d="M15 3v4a1 1 0 0 0 1 1h4"></path>
                                <path d="M18 17h-7a2 2 0 0 1 -2 -2v-10a2 2 0 0 1 2 -2h4l5 5v7a2 2 0 0 1 -2 2z"></path>
                                <path d="M16 17v2a2 2 0 0 1 -2 2h-7a2 2 0 0 1 -2 -2v-10a2 2 0 0 1 2 -2h2"></path>
                            </svg>
                        </x-sidenav-link>
                    </li>
                </ul>
            </div>
        </div>

        @if(request()->routeIs('dash.show'))
            @livewire('dash.users')
        @elseif(request()->routeIs('dash.show.transactions'))
            @livewire('dash.transactions')
        @elseif(request()->routeIs('dash.show.articles'))
            @livewire('dash.articles')
        @elseif(request()->routeIs('dash.show.categories'))
            @livewire('dash.categories')
        @elseif(request()->routeIs('dash.show.files'))
            @livewire('dash.files')
        @endif

    </div>

</x-app-layout>
