<x-app-layout>
    <div class="container">
        <div class="flex justify-center h-screen items-center">
            <figure class="bg-slate-800 py-5 px-10 rounded-xl w-96">
                <div class="my-5 mb-8 flex justify-center h-20">
                    <img src="{{ asset('favicon.svg') }}" alt="favicon">
                </div>

                <h1 class="my-3 text-center text-[14px] text-slate-300">
                    {{ $transaction->title }}
                </h1>

                @if(!$payed)
                    <h1 class="my-3 text-center text-[21px] text-slate-300">Please, dont close this page</h1>
                @endif

                @if($payed)
                    <h1 class="text-center text-[18px] bg-green-400 rounded-lg py-2 px-2 text-slate-200">Payed!</h1>
                @endif

                <section class=" my-5">
                    <div class="flex justify-between items-center">
                        <section>
                            <h1 class="text-slate-400 text-[13px]">TID:</h1>
                            <h1 class="text-slate-400 text-[13px]">Count:</h1>
                            <h1 class="text-slate-400 text-[13px]">Price:</h1>
                            @if(!$payed)
                                <h1 class="text-slate-400 text-[13px]">URL:</h1>
                            @endif
                        </section>
                        <section class="space-y-1">
                            <h1 class="text-slate-400 text-[11px]">{{ $transaction->getUUID() }}</h1>
                            <h1 class="text-slate-400 text-[11px]">{{ $transaction->count }}</h1>
                            <h1 class="text-slate-400 text-[11px]">{{ $transaction->amount }} $</h1>
                            @if(!$payed)
                                <h1 class="text-slate-400 text-[11px]"><a href="{{ $url }}" class="text-sky-400 text-underline">Link (Click)</a></h1>
                            @endif
                        </section>
                    </div>

                    @if($payed)
                        <div class="text-center my-6">
                            @foreach($accounts as $account)
                                <h1 class="text-slate-300 text-[13px]">{{ $account }}</h1>
                            @endforeach
                        </div>
                    @endif
                </section>

                <section class="flex justify-center items-center">
                    @if (!$payed)
                        <button wire:click="check" class="bg-blue-500 py-2 px-4 rounded-xl w-full duration-300 border border-blue-500 hover:bg-inherit text-slate-100">Check</button>
                    @endif
                </section>
            </figure>
        </div>
    </div>
</x-app-layout>
