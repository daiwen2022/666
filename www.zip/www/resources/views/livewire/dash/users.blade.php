<section id="content" class="flex-1 mt-12 w-full mx-12 mb-10">

    <figure class="bg-slate-800 py-4 px-6 rounded-xl">

        <h2 class="text-slate-300 font-bold text-md mb-5">Total Users </h2>

        <section class="flex items-center space-x-5">

            <div class="rounded-full bg-sky-500 py-2 px-2 text-slate-100">
                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-users" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                    <circle cx="9" cy="7" r="4"></circle>
                    <path d="M3 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2"></path>
                    <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                    <path d="M21 21v-2a4 4 0 0 0 -3 -3.85"></path>
                </svg>
            </div>

            <span class="text-4xl text-slate-400">{{ $usersCount }}</span>

            @if ($search != '')
                <span class="text-1xl opacity-75 text-slate-400">({{ $users->count() }} Founded)</span>
            @endif

        </section>

    </figure>


    <div class="mt-12">

        <div class="overflow-x-auto relative">
            <div class="flex justify-between">
                <div class="my-3">
                    <input type="text" name="search" placeholder="Search..." wire:model="search" class="bg-slate-700 rounded-xl py-2 px-4 outline-none border border-slate-700 duration-300 focus:bg-inherit text-slate-300">
                </div>
            </div>
            <table class="w-full text-sm text-left text-gray-400">
                <thead class="text-xs uppercase bg-gray-700 text-gray-400">
                <tr>
                    <th scope="col" class="py-3 px-6">
                        ID
                    </th>
                    <th scope="col" class="py-3 px-6">
                        Name
                    </th>
                    <th scope="col" class="py-3 px-6">
                        EMAIL
                    </th>
                    <th scope="col" class="py-3 px-6">
                        ADMIN
                    </th>
                    <th scope="col" class="py-3 px-6">
                        Created at
                    </th>
                    <th scope="col"></th>
                </tr>
                </thead>
                <tbody>
                @forelse($users as $user)
                    <tr class="border-b bg-gray-800 border-gray-700">
                        <th scope="row" class="py-4 px-6 font-medium text-sky-400 whitespace-nowrap">
                            {{ $user->id }}
                        </th>
                        <td class="py-4 px-6">
                            {{ $user->name }}
                        </td>
                        <td class="py-4 px-6">
                            {{ $user->email }}
                        </td>
                        <td class="py-4 px-6">
                            @if ($user->isAdmin())
                                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-circle-check text-green-400" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                    <circle cx="12" cy="12" r="9"></circle>
                                    <path d="M9 12l2 2l4 -4"></path>
                                </svg>
                            @else
                                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-circle-minus text-red-400" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                    <circle cx="12" cy="12" r="9"></circle>
                                    <line x1="9" y1="12" x2="15" y2="12"></line>
                                </svg>
                            @endif
                        </td>
                        <td class="py-4 px-6">
                            {{ $user->created_at->toFormattedDateString() }}
                        </td>
                        <td class="py-4 px-6 space-x-2 flex items-center">

                            <button wire:click="edit({{ $user }})" class="cursor-pointer">
                                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-pencil" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                    <path d="M4 20h4l10.5 -10.5a1.5 1.5 0 0 0 -4 -4l-10.5 10.5v4"></path>
                                    <line x1="13.5" y1="6.5" x2="17.5" y2="10.5"></line>
                                </svg>
                            </button>

                            <button wire:click="delete({{ $user }})" class="cursor-pointer">
                                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-x" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                    <line x1="18" y1="6" x2="6" y2="18"></line>
                                    <line x1="6" y1="6" x2="18" y2="18"></line>
                                </svg>
                            </button>

                        </td>
                    </tr>
                    @empty
                        <tr class="bg-gray-800">
                            <td colspan="6" class="py-4 px-6 font-medium">
                                <div class="flex justify-center items-center">
                                    <span class="text-2xl opacity-75">No users found...</span>
                                </div>
                            </td>
                        </tr>
                @endforelse
                </tbody>
            </table>
        </div>

        @if (!is_null($editing))
            <form wire:submit.prevent="save">
                <x-modal.dialog wire:model.defer="showEditModal">
                    <x-slot name="title">Edit user</x-slot>
                    <x-slot name="content">



                        <x-input-group for="name" label="Name" :error="$errors->first('editing.name')">
                            <x-input type="text" wire:model="editing.name" id="name" />
                        </x-input-group>

                        <x-input-group for="email" label="EMAIL" :error="$errors->first('editing.email')">
                            <x-input type="email" wire:model="editing.email" id="email" />
                        </x-input-group>

                        <div class="text-center my-3">
                            <button wire:click="toggleAdmin" class="py-2 px-4 rounded-xl bg-gray-900 text-white w-full">TOGGLE ADMIN</button>
                        </div>
                    </x-slot>
                    <x-slot name="footer">
                        <div class="space-x-3">
                            <button wire:click="$toggle('showEditModal')" class="bg-red-500 px-3 py-2 text-white rounded-xl">Cancel</button>
                            <button type="submit" class="bg-gray-900 px-3 py-2 text-white rounded-xl">Save</button>
                        </div>
                    </x-slot>
                </x-modal.dialog>
            </form>
        @endif

    </div>

</section>
