<x-app-layout>

    <h1 class="text-center my-4">Order: {{ $transaction->title }}</h1>
    <h1 class="text-center my-4">Count: {{ $transaction->count }}</h1>
    <h1 class="text-center my-4">Amount: {{ $transaction->amount }} $</h1>
    <h1 class="text-center my-4">Status: {{ $transaction->status }}</h1>
    <h1 class="text-center mt-9">Description</h1>
    <h1 class="text-center mt-2 mb-5">
        {{ $transaction->article->description }}
    </h1>

    <section class="my-8 text-center">

        @foreach(explode(',', $transaction->accounts) as $account)
            <h1 class="text-center text-slate-800">{{ $account }}</h1>
        @endforeach

    </section>

    <section class="my-8 text-center flex justify-center items-center space-x-3">
        <a href="{{ route('transactions.my') }}" class="bg-slate-800 py-2 px-4 rounded-xl text-slate-300 uppercase">My Transactions</a>
        <a href="{{ route('payment.check', $transaction->getUUID()) }}" class="bg-slate-800 py-2 px-4 rounded-xl text-slate-300 uppercase">This Transaction</a>
    </section>

</x-app-layout>
