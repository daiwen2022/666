<x-app-layout>
    <div class="container">
        <div class="flex justify-center h-screen items-center">
            <figure class="bg-slate-800 py-5 px-10 rounded-xl w-96">
                <div class="flex justify-between">
                    <div class="flex-none"></div>
                    <a href="/" class="py-2 px-2 bg-slate-700 rounded-xl mb-2 flex items-center justify-center duration-300 hover:bg-inherit border border-slate-700">
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-arrow-left text-slate-400" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                            <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                            <line x1="5" y1="12" x2="11" y2="18"></line>
                            <line x1="5" y1="12" x2="11" y2="6"></line>
                        </svg>
                    </a>
                </div>
                <div class="my-5 mb-8 flex justify-center h-20">
                    <img src="{{ asset('favicon.svg') }}" alt="favicon">
                </div>

                <section id="inputs">
                    <form action="{{ route('register') }}" method="post" class="space-y-3">
                        @csrf
                        <section class="flex justify-center items-center">
                            <div class="w-full">
                                <input value="{{ old('name') }}" type="text" name="name" class="w-full bg-slate-700 rounded-xl py-2 px-3 outline-none duration-300 border border-slate-700 focus:bg-inherit hover:bg-inherit hover:border-blue-500 text-slate-300 @error('email') border-red-400 @enderror" placeholder="Name">
                                @error('name')
                                <p class="text-center mt-1 text-red-500">{{ $message }}</p>
                                @enderror
                            </div>
                        </section>
                        <section class="flex justify-center items-center">
                            <div class="w-full">
                                <input value="{{ old('email') }}" type="text" name="email" class="w-full bg-slate-700 rounded-xl py-2 px-3 outline-none duration-300 border border-slate-700 focus:bg-inherit hover:bg-inherit hover:border-blue-500 text-slate-300 @error('email') border-red-400 @enderror" placeholder="E-MAIL">
                                @error('email')
                                <p class="text-center mt-1 text-red-500">{{ $message }}</p>
                                @enderror
                            </div>
                        </section>
                        <section class="flex justify-center items-center">
                            <div class="w-full">
                                <input type="password" name="password" class="w-full bg-slate-700 rounded-xl py-2 px-3 outline-none duration-300 border border-slate-700 focus:bg-inherit hover:bg-inherit hover:border-blue-500 text-slate-300 @error('password') border-red-400 @enderror" placeholder="Password">
                            </div>
                        </section>

                        <section class="flex justify-center items-center">
                            <div class="w-full">
                                <input type="password" id="password-confirm" name="password_confirmation" class="w-full bg-slate-700 rounded-xl py-2 px-3 outline-none duration-300 border border-slate-700 focus:bg-inherit hover:bg-inherit hover:border-blue-500 text-slate-300 @error('password') border-red-400 @enderror" placeholder="Password confirm">
                                @error('password')
                                <p class="text-center mt-1 text-red-500">{{ $message }}</p>
                                @enderror
                            </div>
                        </section>
                        <section class="flex justify-center items-center">
                            <button type="submit" class="bg-blue-500 py-2 px-4 rounded-xl w-full duration-300 border border-blue-500 hover:bg-inherit text-slate-100">Sign Up</button>
                        </section>
                        <section class="flex justify-center md:text-[15px] sm:text-[13px]">
                            <a href="{{ route('login') }}" class="text-slate-400">
                                Already registered?
                            </a>
                        </section>
                    </form>
                </section>
            </figure>
        </div>
    </div>
</x-app-layout>
