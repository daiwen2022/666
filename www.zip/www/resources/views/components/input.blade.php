<div class="flex rounded-md shadow-sm">


    <input {{ $attributes->merge(['class' => 'flex-1 outline-none py-2 px-3 border rounded-xl duration-300 focus:border-sky-500']) }}/>
</div>
