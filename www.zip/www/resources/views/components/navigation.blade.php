<nav class="container flex items-center justify-center my-12 xl:text-[12px]">

    <ul class="flex items-center space-x-[100px]">
        <li>

            <x-nav-link href="/" :active="request()->routeIs('welcome')" class="flex items-center space-x-3">

                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-home-2 text-main" width="24"
                     height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                     stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                    <polyline points="5 12 3 12 12 3 21 12 19 12"></polyline>
                    <path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-7"></path>
                    <rect x="10" y="12" width="4" height="4"></rect>
                </svg>

                <span>Main</span>
            </x-nav-link>

        </li>

        <li>

            <x-nav-link href="{{ route('guarantee') }}" :active="request()->routeIs('guarantee')"
                        class="flex items-center space-x-3">

                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-blockquote text-main"
                     width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                     stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                    <path d="M6 15h15"></path>
                    <path d="M21 19h-15"></path>
                    <path d="M15 11h6"></path>
                    <path d="M21 7h-6"></path>
                    <path d="M9 9h1a1 1 0 1 1 -1 1v-2.5a2 2 0 0 1 2 -2"></path>
                    <path d="M3 9h1a1 1 0 1 1 -1 1v-2.5a2 2 0 0 1 2 -2"></path>
                </svg>

                <span>Rules</span>
            </x-nav-link>

        </li>

        <li>

            <x-nav-link href="{{ route('howtobuy') }}" :active="request()->routeIs('howtobuy')"
                        class="flex items-center space-x-3">

                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-help text-main" width="24"
                     height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                     stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                    <circle cx="12" cy="12" r="9"></circle>
                    <line x1="12" y1="17" x2="12" y2="17.01"></line>
                    <path d="M12 13.5a1.5 1.5 0 0 1 1 -1.5a2.6 2.6 0 1 0 -3 -4"></path>
                </svg>

                <span>How to buy?</span>
            </x-nav-link>

        </li>

        <li>

            <x-nav-link href="https://telegra.ph/Aktivaciya-Office-2019-i-2016-Pro-Plus-10-10"
                        class="flex items-center space-x-3">

                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-lock-open text-main"
                     width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                     stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                    <rect x="5" y="11" width="14" height="10" rx="2"></rect>
                    <circle cx="12" cy="16" r="1"></circle>
                    <path d="M8 11v-5a4 4 0 0 1 8 0"></path>
                </svg>

                <span>Key activation</span>
            </x-nav-link>

        </li>

        @guest
            <li>
                <x-nav-link href="{{ route('login') }}" class="flex items-center space-x-3 cursor-pointer">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-user text-main"
                         width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                         stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                        <circle cx="12" cy="7" r="4"></circle>
                        <path d="M6 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2"></path>
                    </svg>

                    <span>Sign In</span>
                </x-nav-link>
            </li>
        @endguest

        @auth
            <li>
                <x-dropdown :width="48">
                    <x-slot name="trigger">
                        <x-nav-link class="flex items-center space-x-3 cursor-pointer">
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-user text-main"
                                 width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"
                                 fill="none" stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                <circle cx="12" cy="7" r="4"></circle>
                                <path d="M6 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2"></path>
                            </svg>

                            <span>{{ Auth::user()->name }}</span>
                        </x-nav-link>
                    </x-slot>

                    <x-slot name="content">
                        <x-dropdown-link href="/transactions/my"
                                         class="w-full py-2 px-2 duration-300 hover:bg-slate-200 flex items-center space-x-3">
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-receipt"
                                 width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"
                                 fill="none" stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                <path
                                    d="M5 21v-16a2 2 0 0 1 2 -2h10a2 2 0 0 1 2 2v16l-3 -2l-2 2l-2 -2l-2 2l-2 -2l-3 2m4 -14h6m-6 4h6m-2 4h2"></path>
                            </svg>

                            <span>My Transactions</span>
                        </x-dropdown-link>

                        <form action="{{ route('logout') }}" method="post" x-data>
                            @csrf
                            <x-dropdown-link href="{{ route('logout') }}" @click.prevent="$root.submit();"
                                             class="w-full py-2 px-2 duration-300 hover:bg-slate-200 flex items-center space-x-3">
                                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-logout"
                                     width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"
                                     fill="none" stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                    <path
                                        d="M14 8v-2a2 2 0 0 0 -2 -2h-7a2 2 0 0 0 -2 2v12a2 2 0 0 0 2 2h7a2 2 0 0 0 2 -2v-2"></path>
                                    <path d="M7 12h14l-3 -3m0 6l3 -3"></path>
                                </svg>

                                <span>Logout</span>
                            </x-dropdown-link>
                        </form>
                    </x-slot>
                </x-dropdown>
            </li>
        @endauth

        @auth
            <li>
                <x-dropdown :width="96">
                    <x-slot name="trigger">
                        <x-nav-link class="flex items-center space-x-3 cursor-pointer">
                            <svg xmlns="http://www.w3.org/2000/svg"
                                 class="icon icon-tabler icon-tabler-garden-cart text-main" width="24" height="24"
                                 viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                 stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                <circle cx="17.5" cy="17.5" r="2.5"></circle>
                                <path d="M6 8v11a1 1 0 0 0 1.806 .591l3.694 -5.091v.055"></path>
                                <path
                                    d="M6 8h15l-3.5 7l-7.1 -.747a4 4 0 0 1 -3.296 -2.493l-2.853 -7.13a1 1 0 0 0 -.928 -.63h-1.323"></path>
                            </svg>

                            <span>Cart</span>
                        </x-nav-link>
                    </x-slot>

                    <x-slot name="content">
                        @forelse(Auth::user()->cart as $celement)
                            @php $carticle = $celement->article @endphp
                            <div class="my-4 mx-2 py-2 px-2 border border-slate-400 rounded-lg">
                                <div class="flex justify-between items-center">
                                    <section>
                                        <h3 class="text-slate-500 text-[13px]">{{ Str::limit($carticle->title, 30, $end='...') }}</h3>
                                        <p class="text-slate-400 text-[11px]">{{ $carticle->description }}</p>
                                        <p class="text-slate-400 text-[11px]">{{ $carticle->price * $celement->count }}
                                            $ - QTY. {{ $celement->count }}</p>
                                    </section>
                                    <section class="flex items-center gap-x-2">
                                        <a href="{{ route('payment.show', $carticle->id) }}"
                                           class="py-2 px-2 bg-blue-400 duration-300 hover:bg-inherit hover:text-slate-800 border border-blue-400 text-slate-100 rounded-lg">Buy</a>
                                        <a href="{{ route('payment.cart.remove', $celement->id) }}"
                                           class="py-2 px-2 bg-blue-400 duration-300 hover:bg-inherit hover:text-slate-800 border border-blue-400 text-slate-100 rounded-lg">
                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                 class="icon icon-tabler icon-tabler-x" width="24" height="24"
                                                 viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                                 stroke-linecap="round" stroke-linejoin="round">
                                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                                <line x1="18" y1="6" x2="6" y2="18"></line>
                                                <line x1="6" y1="6" x2="18" y2="18"></line>
                                            </svg>
                                        </a>
                                    </section>
                                </div>
                            </div>
                        @empty
                            <div class="text-center my-4">
                                <h3 class="text-slate-500">Empty</h3>
                            </div>
                        @endforelse
                    </x-slot>
                </x-dropdown>
            </li>
        @endauth
    </ul>

</nav>
