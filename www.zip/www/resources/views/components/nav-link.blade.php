@props(['active'])

@php
    $classes = ($active ?? false)
        ? 'text-main font-medium border-b border-main py-2'
        : 'text-slate-300 font-medium duration-300 py-2 border-gray-900 hover:border-b hover:border-main';
@endphp

<a {{ $attributes->merge(['class' => $classes]) }}>
    {{ $slot }}
</a>
