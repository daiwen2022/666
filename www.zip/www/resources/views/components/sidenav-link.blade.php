@props(['active'])

@php
    $classes = ($active ?? false)
        ? 'rounded-full py-3 px-3 bg-blue-500 text-slate-100 duration-300'
        : 'rounded-full py-3 px-3 bg-slate-700 text-slate-100 duration-300 hover:bg-inherit';
@endphp

<a {{ $attributes->merge(['class' => $classes]) }}>
    {{ $slot }}
</a>
