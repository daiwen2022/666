<x-app-layout>

    <div class="bgs__video w-auto h-auto overflow-hidden fixed z-[-999] left-0 right-0 top-0 bottom-0" style="opacity: 1;">
        <video id="bgvideo" class="bgvideo w-auto h-auto min-w-[100%] min-h-[100%] border-[0] opacity-[0.3]" poster="https://i.imgur.com/ODpemDt.jpg" loop="" autoplay="" muted="" playsinline="">
            <source src="https://bsteam.clan.su/filesbg/animatebg.mp4" type="video/mp4">
        </video>
    </div>

    <header>
        <x-navigation />
    </header>

    <div class="container mt-12">
        <div class="flex justify-center">
            <span style="color: rgb(255, 255, 255);"><span style="font-size: 24px; font-weight: bold;">商店的规则</span><br> 在“YUN123.ORG”网站上购买商品时 <br>您自动同意以下规则：<br> <br>商店规则和产品保修：（一般.） <br>1、如您更改账号密码，本店不负责账号恢复.<br>2. 每个账户保证 - 24 小时.<br>3. 只有在缺货的情况下才可退款. <br>4. 侮辱、不尊重他人的行为.  - 取消保修。 <br>5. 账户上的订阅日期不是保证. <br>6. 如果您对购买的产品有误，则无法更换或退货. <br>7. 如果该帐户被禁止并在保修期内被更换，那么我不会对该帐户进行后续更换. <br>8. 忠于您，即使在保修期后更换，如果帐户没有足够的期限. <br><br>Minecraft 帐户的保修: <br>1. 帐号失效时补发. （无效日志：密码.） <br>2. 禁止 Hypixel（如果安全警报标志 - 我们不会帮助您.) <br>3. 仅当您有购买视频时才会发出更换. <br>4. 如果您不喜欢昵称/皮肤，则退还帐户 - 不会执行. <br>5. 保修 - 自购买之日起 20 分钟。 商店支持有权拒绝给您更换 Minecraft 帐户而无需给出理由.</span>
        </div>
    </div>
</x-app-layout>
