<x-app-layout>
    <div class="container">
        <div class="flex justify-center h-screen items-center">
            <figure class="bg-slate-800 py-5 px-10 rounded-xl w-auto">
                <div class="flex justify-between">
                    <div class="flex-none"></div>
                    <a href="/" class="py-2 px-2 bg-slate-700 rounded-xl mb-2 flex items-center justify-center duration-300 hover:bg-inherit border border-slate-700">
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-arrow-left text-slate-400" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                            <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                            <line x1="5" y1="12" x2="11" y2="18"></line>
                            <line x1="5" y1="12" x2="11" y2="6"></line>
                        </svg>
                    </a>
                </div>
                <div class="my-5 mb-8 flex justify-center h-20">
                    <img src="{{ asset('favicon.svg') }}" alt="favicon">
                </div>

                <h1 class="my-3 text-slate-300">
                    {{ $article->title }}
                </h1>

                <h1 class="my-3 text-slate-500">
                    {{ $article->description }}
                </h1>

                <h1 class="my-3 text-slate-500">
                    {{ $article->price }}$ per 1
                </h1>

                <section id="inputs">
                    <form action="{{ route('payment.create') }}" method="post" class="space-y-3">
                        @csrf

                        <input type="text" hidden name="articleid" value="{{ $article->id }}">

                        <section class="flex justify-center items-center">
                            <div class="w-full">
                                <label for="email" class="text-slate-300">Email</label>
                                <input type=email id="email" name="email" class="w-full mt-2 bg-slate-700 rounded-xl py-2 px-3 outline-none duration-300 border border-slate-700 focus:bg-inherit hover:bg-inherit hover:border-blue-500 text-slate-300 @error('email') border-red-400 @enderror" placeholder="E-Mail" value="@auth {{ Auth::user()->email }} @endauth">
                                @error('email')
                                <p class="text-center mt-1 text-red-500">{{ $message }}</p>
                                @enderror
                            </div>
                        </section>

                        <section class="flex justify-center items-center">
                            <div class="w-full">
                                <label for="count" class="text-slate-300">Count (max: {{ $article->count }})</label>
                                <input type="text" id="count" name="count" class="w-full mt-2 bg-slate-700 rounded-xl py-2 px-3 outline-none duration-300 border border-slate-700 focus:bg-inherit hover:bg-inherit hover:border-blue-500 text-slate-300 @error('count') border-red-400 @enderror" placeholder="Count (n / {{ $article->count }})" value="1">
                                @error('count')
                                <p class="text-center mt-1 text-red-500">{{ $message }}</p>
                                @enderror
                            </div>
                        </section>
                        <section class="flex justify-center items-center">
                            <button type="submit" class="bg-blue-500 py-2 px-4 rounded-xl w-full duration-300 border border-blue-500 hover:bg-inherit text-slate-100">Create payment</button>
                        </section>
                        @auth
                            <div class="p-4">
                                <div class="flex justify-center items-center gap-x-4 mr-4 mb-2">
                                    <input type="checkbox" id="cart" name="cart" class="h-6 w-6 rounded-lg duration-300" />
                                    <label for="cart" class="select-none text-slate-300 text-[16px]">Add to cart</label>
                                </div>
                            </div>
                        @endauth
                    </form>
                </section>
            </figure>
        </div>
    </div>
</x-app-layout>
