<?php

return [

    'payments' => [
        'driver' => env('PAYMENT_DRIVER', 'crystalpay')
    ]

];
