<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('title', null, []); ?> Dashboard <?php $__env->endSlot(); ?>

    <div class="relative flex min-h-screen">

        <div class="bg-slate-800 text-slate-300 py-8 px-5 text-center">
            <div class="flex justify-center">
                <a href="<?php echo e(route('dash.show')); ?>" class="">
                    <img src="<?php echo e(asset('favicon.svg')); ?>" alt="favicon" class="h-20 border-b border-slate-500 pb-6">
                </a>
            </div>

            <div class="flex justify-center">
                <ul class="mt-6 space-y-5">
                    <li class="flex">
                        <a href="/" class="rounded-full py-3 px-3 bg-slate-700 text-slate-100 duration-300 hover:bg-inherit">
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-layout-dashboard" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                <path d="M4 4h6v8h-6z"></path>
                                <path d="M4 16h6v4h-6z"></path>
                                <path d="M14 12h6v8h-6z"></path>
                                <path d="M14 4h6v4h-6z"></path>
                            </svg>
                        </a>
                    </li>

                    <li class="flex">
                        <a href="/" class="rounded-full py-3 px-3 bg-slate-700 text-slate-100 duration-300 hover:bg-inherit">
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-news" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                <path d="M16 6h3a1 1 0 0 1 1 1v11a2 2 0 0 1 -4 0v-13a1 1 0 0 0 -1 -1h-10a1 1 0 0 0 -1 1v12a3 3 0 0 0 3 3h11"></path>
                                <line x1="8" y1="8" x2="12" y2="8"></line>
                                <line x1="8" y1="12" x2="12" y2="12"></line>
                                <line x1="8" y1="16" x2="12" y2="16"></line>
                            </svg>
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        <?php if(request()->routeIs('dash.show')): ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dash.users')->html();
} elseif ($_instance->childHasBeenRendered('G1cg0bO')) {
    $componentId = $_instance->getRenderedChildComponentId('G1cg0bO');
    $componentTag = $_instance->getRenderedChildComponentTagName('G1cg0bO');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('G1cg0bO');
} else {
    $response = \Livewire\Livewire::mount('dash.users');
    $html = $response->html();
    $_instance->logRenderedChild('G1cg0bO', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php elseif(request()->routeIs('dash.show.transactions')): ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dash.transactions')->html();
} elseif ($_instance->childHasBeenRendered('mloyiOP')) {
    $componentId = $_instance->getRenderedChildComponentId('mloyiOP');
    $componentTag = $_instance->getRenderedChildComponentTagName('mloyiOP');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('mloyiOP');
} else {
    $response = \Livewire\Livewire::mount('dash.transactions');
    $html = $response->html();
    $_instance->logRenderedChild('mloyiOP', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php endif; ?>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\wavestore\resources\views/admin/show.blade.php ENDPATH**/ ?>