<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <div class="flex justify-center h-screen items-center">
            <figure class="bg-slate-800 py-5 px-10 rounded-xl w-auto">
                <div class="flex justify-between">
                    <div class="flex-none"></div>
                    <a href="/" class="py-2 px-2 bg-slate-700 rounded-xl mb-2 flex items-center justify-center duration-300 hover:bg-inherit border border-slate-700">
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-arrow-left text-slate-400" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                            <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                            <line x1="5" y1="12" x2="11" y2="18"></line>
                            <line x1="5" y1="12" x2="11" y2="6"></line>
                        </svg>
                    </a>
                </div>
                <div class="my-5 mb-8 flex justify-center h-20">
                    <img src="<?php echo e(asset('favicon.svg')); ?>" alt="favicon">
                </div>

                <h1 class="my-3 text-slate-300">
                    <?php echo e($article->title); ?>

                </h1>

                <h1 class="my-3 text-slate-500">
                    <?php echo e($article->description); ?>

                </h1>

                <h1 class="my-3 text-slate-500">
                    <?php echo e($article->price); ?>$ per 1
                </h1>

                <section id="inputs">
                    <form action="<?php echo e(route('payment.create')); ?>" method="post" class="space-y-3">
                        <?php echo csrf_field(); ?>

                        <input type="text" hidden name="articleid" value="<?php echo e($article->id); ?>">

                        <section class="flex justify-center items-center">
                            <div class="w-full">
                                <label for="email" class="text-slate-300">Email</label>
                                <input type=email id="email" name="email" class="w-full mt-2 bg-slate-700 rounded-xl py-2 px-3 outline-none duration-300 border border-slate-700 focus:bg-inherit hover:bg-inherit hover:border-blue-500 text-slate-300 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="E-Mail" value="<?php if(auth()->guard()->check()): ?> <?php echo e(Auth::user()->email); ?> <?php endif; ?>">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-center mt-1 text-red-500"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </section>

                        <section class="flex justify-center items-center">
                            <div class="w-full">
                                <label for="count" class="text-slate-300">Count (max: <?php echo e($article->count); ?>)</label>
                                <input type="text" id="count" name="count" class="w-full mt-2 bg-slate-700 rounded-xl py-2 px-3 outline-none duration-300 border border-slate-700 focus:bg-inherit hover:bg-inherit hover:border-blue-500 text-slate-300 <?php $__errorArgs = ['count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Count (n / <?php echo e($article->count); ?>)" value="1">
                                <?php $__errorArgs = ['count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-center mt-1 text-red-500"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </section>
                        <section class="flex justify-center items-center">
                            <button type="submit" class="bg-blue-500 py-2 px-4 rounded-xl w-full duration-300 border border-blue-500 hover:bg-inherit text-slate-100">Create payment</button>
                        </section>
                        <?php if(auth()->guard()->check()): ?>
                            <div class="p-4">
                                <div class="flex justify-center items-center gap-x-4 mr-4 mb-2">
                                    <input type="checkbox" id="cart" name="cart" class="h-6 w-6 rounded-lg duration-300" />
                                    <label for="cart" class="select-none text-slate-300 text-[16px]">Add to cart</label>
                                </div>
                            </div>
                        <?php endif; ?>
                    </form>
                </section>
            </figure>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\resources\views/pay/payment.blade.php ENDPATH**/ ?>