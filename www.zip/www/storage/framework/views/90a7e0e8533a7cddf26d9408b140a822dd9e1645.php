<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <h1 class="text-center my-4">Order: <?php echo e($transaction->title); ?></h1>
    <h1 class="text-center my-4">Count: <?php echo e($transaction->count); ?></h1>
    <h1 class="text-center my-4">Amount: <?php echo e($transaction->amount); ?> $</h1>
    <h1 class="text-center my-4">Status: <?php echo e($transaction->status); ?></h1>
    <h1 class="text-center mt-9">Description</h1>
    <h1 class="text-center mt-2 mb-5">
        <?php echo e($transaction->article->description); ?>

    </h1>

    <section class="my-8 text-center">

        <?php $__currentLoopData = explode(',', $transaction->accounts); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h1 class="text-center text-slate-800"><?php echo e($account); ?></h1>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </section>

    <section class="my-8 text-center flex justify-center items-center space-x-3">
        <a href="<?php echo e(route('transactions.my')); ?>" class="bg-slate-800 py-2 px-4 rounded-xl text-slate-300 uppercase">My Transactions</a>
        <a href="<?php echo e(route('payment.check', $transaction->getUUID())); ?>" class="bg-slate-800 py-2 px-4 rounded-xl text-slate-300 uppercase">This Transaction</a>
    </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\resources\views/mail/successtransaction.blade.php ENDPATH**/ ?>