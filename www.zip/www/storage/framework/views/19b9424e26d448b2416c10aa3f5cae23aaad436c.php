<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="bgs__video w-auto h-auto overflow-hidden fixed z-[-999] left-0 right-0 top-0 bottom-0" style="opacity: 1;">
        <video id="bgvideo" class="bgvideo w-auto h-auto min-w-[100%] min-h-[100%] border-[0] opacity-[0.3]" poster="https://i.imgur.com/ODpemDt.jpg" loop="" autoplay="" muted="" playsinline="">
            <source src="https://bsteam.clan.su/filesbg/animatebg.mp4" type="video/mp4">
        </video>
    </div>

    <header>
        <?php if (isset($component)) { $__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e = $component; } ?>
<?php $component = App\View\Components\Navigation::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Navigation::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e)): ?>
<?php $component = $__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e; ?>
<?php unset($__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e); ?>
<?php endif; ?>
    </header>

    <div class="container mt-12">
        <div class="flex justify-center">
            <span style="color: rgb(255, 255, 255);"><span style="font-size: 24px; font-weight: bold;">ВНУТРЕННИЕ ПРАВИЛА МАГАЗИНА LUXSTOREPW.DEER.IS</span><br> При покупке товара на сайте “LUXSTOREPW.DEER.IS” <br>Вы автоматически соглашаетесь со следующими правилами:<br> <br>Правила магазина и гарантия на товары: (Общее.) <br>1. Магазин не несет ответственности за восстановление аккаунта, если вы сменили пароль от аккаунта. <br>2. Гарантия на каждый аккаунт - 24 часа.<br>3. Возврат денег за товар только в случае его отсутствия. <br>4. Оскорбление, неуважительное поведение к тех. поддержке - снятие гарантии. <br>5. Дата подписки на аккаунте - не гарантия. <br>6. Если вы ошиблись с приобретаемым товаром, замену или возврату он не подлежит. <br>7. Если аккаунт отлетел и была произведена замена по гарантии, то последующую замену этого аккаунта не даю. <br>8. Лоялен к вам и заменяю даже после сроков гарантии, если аккаунт не прожил адекватный срок. <br><br>Гарантия для аккаунтов Minecraft: <br>1. Замена производится в случае не валидности аккаунта. (Неверный log:pass.) <br>2. Бана на Hypixel (Если табличка Security Alert - мы вам не поможем.) <br>3. Замена выдается только если у вас была видеозапись покупки. <br>4. Возврат аккаунта если вам не понравился ник/скин - не осуществляется. <br>5. Гарантия - 20 минут с момента покупки. Поддержка магазина в праве отказать вам в выдаче замены аккаунта Minecraft без объяснения причины. <br><br>Отзывы о нас на ведущих форумах: <br>► https://bhf.im/threads/638454/ <br>► https://lolz.guru/threads/2416979/ <br>► https://youhack.xyz/threads/912855/ <br>► https://yougame.biz/threads/195914/ <br>► https://mesto.dark2web.biz/threads/146270/ <br>► https://vlmi.ws/threads/bolshoj-assortiment-akkauntov-vpn-windscribe-nord-surfshark-proton-plus.45900/ <br>► https://piratebuhta.me/threads/magazin-vpn-proton-plus-windscribe-pro-nord-premium-surfshark-ipvanish-tunnelbear.50134/ <br>► https://probiv.one/threads/vpn-proton-nord-windscribe-vypr-zenmate-browsec-tunnelbear-giant-hma-cyberghost-surfshak.99552/ <br>► https://mipped.com/f/threads/vpn-i-kinoservisy-nord-windscribe-netflix-more-tv-ivi-proton-plus-surfshark-express-vpn-i-mnogoe-drugoe.168572/</span>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\resources\views/guarantee.blade.php ENDPATH**/ ?>