<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="bgs__video w-auto h-auto overflow-hidden fixed z-[-999] left-0 right-0 top-0 bottom-0" style="opacity: 1;">
        <video id="bgvideo" class="bgvideo w-auto h-auto min-w-[100%] min-h-[100%] border-[0] opacity-[0.3]" poster="https://i.imgur.com/ODpemDt.jpg" loop="" autoplay="" muted="" playsinline="">
            <source src="https://bsteam.clan.su/filesbg/animatebg.mp4" type="video/mp4">
        </video>
    </div>

    <header>
        <?php if (isset($component)) { $__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e = $component; } ?>
<?php $component = App\View\Components\Navigation::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Navigation::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e)): ?>
<?php $component = $__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e; ?>
<?php unset($__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e); ?>
<?php endif; ?>
    </header>

    <div class="container mt-12">
        <div class="flex justify-center">
            <div class="infopage__igr0k">
                <p style="color: white;"><span style="color: rgb(255, 255, 255);"><span style="font-size: 24px; font-weight: bold;">КАК КУПИТЬ ТОВАР НА LUXSTOREPW.DEER.IS?</span>
	</span>
                </p>
                <p style="color: white;"><span style="color: rgb(255, 255, 255);">Чтобы приобрести любой из наших товаров, вам необходимо нажать на кнопку "Купить".<br><br>В появившемся окне:<br>
	</span>
                </p>
                <p style="color: white;"><span style="color: rgb(255, 255, 255);">1. Укажите свой адрес электронной почты, товар будет доставлен туда
	</span>
                </p>
                <p style="color: white;"><span style="color: rgb(255, 255, 255);">2. Введите желаемое количество продукта
	</span>
                </p>
                <p style="color: white;"><span style="color: rgb(255, 255, 255);">3. Выберите удобный для вас способ оплаты
	</span>
                </p>
                <p style="color: white;"><span style="color: rgb(255, 255, 255);">4. Нажмите на кнопку "Перейти к оплате".<br><br>
	</span>
                </p>
                <p style="color: white;"><span style="color: rgb(255, 255, 255);">Вы увидите окно с суммой заказа, реквизитами оплаты товара и примечанием. Важно!
	</span>
                </p>
                <p style="color: white;"><span style="color: rgb(255, 255, 255);">Примечание к платежу введите с #<br><br>
	</span>
                </p>
                <p style="color: white;"><span style="color: rgb(255, 255, 255);">Затем перейдите в свою платежную систему и укажите в соответствующих полях.
	</span>
                </p>
                <p style="color: white;"><strong><span style="color: rgb(255, 255, 255);">После оплаты нажмите кнопку "Проверить платеж".</span></strong>
                </p>
            </div>        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\resources\views/howtobuy.blade.php ENDPATH**/ ?>