<div class="flex rounded-md shadow-sm">


    <input <?php echo e($attributes->merge(['class' => 'flex-1 outline-none py-2 px-3 border rounded-xl duration-300 focus:border-sky-500'])); ?>/>
</div>
<?php /**PATH C:\laragon\www\wavestore\resources\views/components/input.blade.php ENDPATH**/ ?>