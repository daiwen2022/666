<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <div class="flex justify-center h-screen items-center">
            <figure class="bg-slate-800 py-5 px-10 rounded-xl w-96">
                <div class="my-5 mb-8 flex justify-center h-20">
                    <img src="<?php echo e(asset('favicon.svg')); ?>" alt="favicon">
                </div>

                <h1 class="my-3 text-center text-[14px] text-slate-300">
                    <?php echo e($transaction->title); ?>

                </h1>

                <?php if(!$payed): ?>
                    <h1 class="my-3 text-center text-[21px] text-slate-300">Please, dont close this page</h1>
                <?php endif; ?>

                <?php if($payed): ?>
                    <h1 class="text-center text-[18px] bg-green-400 rounded-lg py-2 px-2 text-slate-200">Payed!</h1>
                <?php endif; ?>

                <section class=" my-5">
                    <div class="flex justify-between items-center">
                        <section>
                            <h1 class="text-slate-400 text-[13px]">TID:</h1>
                            <h1 class="text-slate-400 text-[13px]">Count:</h1>
                            <h1 class="text-slate-400 text-[13px]">Price:</h1>
                            <?php if(!$payed): ?>
                                <h1 class="text-slate-400 text-[13px]">URL:</h1>
                            <?php endif; ?>
                        </section>
                        <section class="space-y-1">
                            <h1 class="text-slate-400 text-[11px]"><?php echo e($transaction->getUUID()); ?></h1>
                            <h1 class="text-slate-400 text-[11px]"><?php echo e($transaction->count); ?></h1>
                            <h1 class="text-slate-400 text-[11px]"><?php echo e($transaction->amount); ?> $</h1>
                            <?php if(!$payed): ?>
                                <h1 class="text-slate-400 text-[11px]"><a href="<?php echo e($url); ?>" class="text-sky-400 text-underline">Link (Click)</a></h1>
                            <?php endif; ?>
                        </section>
                    </div>

                    <?php if($payed): ?>
                        <div class="text-center my-6">
                            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <h1 class="text-slate-300 text-[13px]"><?php echo e($account); ?></h1>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </section>

                <section class="flex justify-center items-center">
                    <?php if(!$payed): ?>
                        <button wire:click="check" class="bg-blue-500 py-2 px-4 rounded-xl w-full duration-300 border border-blue-500 hover:bg-inherit text-slate-100">Check</button>
                    <?php endif; ?>
                </section>
            </figure>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\resources\views/livewire/pay/payment.blade.php ENDPATH**/ ?>