<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="bgs__video w-auto h-[100vh] overflow-hidden fixed z-[-999] left-0 right-0 top-0 bottom-0"
         style="opacity: 1;">
        <video id="bgvideo" class="bgvideo w-auto h-[100vh] border-[0] opacity-[0.3]"
               poster="https://i.imgur.com/ODpemDt.jpg" loop="" autoplay="" muted="" playsinline="">
            <source src="https://bsteam.clan.su/filesbg/animatebg.mp4" type="video/mp4">
        </video>
    </div>

     <?php $__env->slot('title', null, []); ?> WAVESTORE | Магазин аккаунтов <?php $__env->endSlot(); ?>

    <header>
        <?php if (isset($component)) { $__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e = $component; } ?>
<?php $component = App\View\Components\Navigation::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Navigation::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e)): ?>
<?php $component = $__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e; ?>
<?php unset($__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e); ?>
<?php endif; ?>
    </header>

    <main class="mt-[70px] mb-[20px]">
        <div class="hero">
            <div class="container text-center">

                <div class="flex justify-center mb-[50px]">
                    <img src="<?php echo e(asset('favicon.svg')); ?>" class="h-28" alt="favicon">
                </div>

                <h1 class="text-slate-200 font-semibold text-5xl md:text-2xl">Popular VPN and other products store</h1>
                <p class="text-slate-400 mt-4">WAVESTORE is a popular store of accounts for a variety of products</p>

            </div>
        </div>

        <div class="container mt-12">
            <section class="flex items-center justify-center gap-12">
                <a href="t.me/"
                   class="flex items-center space-x-6 bg-slate-800 py-2 pr-6 pl-5 rounded-xl duration-300 border border-slate-800 hover:bg-transparent hover:border-slate-600">
                    <img src="https://ruju.ru/bitrix/templates/aspro_next/images/telegram-logo-2.png"
                         class="h-16 lg:h-12 md:h-8 rounded-full" alt="">
                    <div>
                        <h1 class="font-medium text-slate-200 text-[18px] lg:text-[14px] md:text-[12px]">Those.
                            Support</h1>
                        <p class="text-slate-400 text-[17px] lg:hidden">Questions about the store</p>
                    </div>
                </a>

                <a href="t.me/"
                   class="flex items-center space-x-6 bg-slate-800 py-2 pr-6 pl-5 rounded-xl duration-300 border border-slate-800 hover:bg-transparent hover:border-slate-600">
                    <img src="https://ruju.ru/bitrix/templates/aspro_next/images/telegram-logo-2.png"
                         class="h-16 lg:h-12 md:h-8 rounded-full" alt="">
                    <div>
                        <h1 class="font-medium text-slate-200 text-[18px] lg:text-[14px] md:text-[12px]">Telegram
                            channel</h1>
                        <p class="text-slate-400 text-[17px] lg:hidden">Promotions and discounts</p>
                    </div>
                </a>
            </section>
        </div>

        <?php if($categories): ?>
            <div class="container mt-12">
                <div class="nav nav-cat list-none text-center">
                    <div class="list-group space-x-5">

                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="/categories/<?php echo e($category->id); ?>/view"
                               class="px-12 lg:px-8 md:px-4 sm:px-2 xsm:px-1 py-3 rounded-xl bg-slate-800 text-slate-300 duration-300 hover:bg-main hover:text-slate-800">
                                <?php echo e($category->title); ?>

                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>

                <div class="mt-10 w-full">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!$category->articles->isEmpty()): ?>
                            <div class="h-[0.5px] bg-slate-600 mb-5"></div>
                            <?php $__currentLoopData = $category->articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('payment.show', $article->id)); ?>"
                                   class="py-4 px-8 rounded-xl text-slate-200 bg-slate-800 w-full flex items-center w-full mb-4">
                                    <div class="flex justify-between items-center w-full">
                                        <section>
                                            <h1><?php echo e($article->title); ?></h1>
                                            <h1 class="text-[13px] text-slate-400"><?php echo e($article->price); ?> $ /
                                                1</h1>
                                            <h1 class="text-[13px] text-slate-400">
                                                Count: <?php echo e($article->count); ?></h1>
                                        </section>
                                        <section>
                                        <span
                                            class="border border-main py-1 px-4 rounded-xl"><?php echo e($article->category->title); ?></span>
                                        </section>
                                    </div>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="h-[0.5px] bg-slate-600"></div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
    <?php endif; ?>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\resources\views/welcome.blade.php ENDPATH**/ ?>