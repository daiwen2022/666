<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="container">
        <div class="flex justify-center h-screen items-center">
            <figure class="bg-slate-800 py-5 px-10 rounded-xl w-96">
                <div class="my-5 mb-8 flex justify-center h-20 -space-x-6">
                    <img src="<?php echo e(asset('favicon.svg')); ?>" alt="favicon">
                    <svg xmlns="http://www.w3.org/2000/svg" id="Layer_1" data-name="Layer 1"
                         viewBox="0 0 339.43 295.27"><title>tether-usdt-logo</title>
                        <path
                            d="M62.15,1.45l-61.89,130a2.52,2.52,0,0,0,.54,2.94L167.95,294.56a2.55,2.55,0,0,0,3.53,0L338.63,134.4a2.52,2.52,0,0,0,.54-2.94l-61.89-130A2.5,2.5,0,0,0,275,0H64.45a2.5,2.5,0,0,0-2.3,1.45h0Z"
                            style="fill:#50af95;fill-rule:evenodd"/>
                        <path
                            d="M191.19,144.8v0c-1.2.09-7.4,0.46-21.23,0.46-11,0-18.81-.33-21.55-0.46v0c-42.51-1.87-74.24-9.27-74.24-18.13s31.73-16.25,74.24-18.15v28.91c2.78,0.2,10.74.67,21.74,0.67,13.2,0,19.81-.55,21-0.66v-28.9c42.42,1.89,74.08,9.29,74.08,18.13s-31.65,16.24-74.08,18.12h0Zm0-39.25V79.68h59.2V40.23H89.21V79.68H148.4v25.86c-48.11,2.21-84.29,11.74-84.29,23.16s36.18,20.94,84.29,23.16v82.9h42.78V151.83c48-2.21,84.12-11.73,84.12-23.14s-36.09-20.93-84.12-23.15h0Zm0,0h0Z"
                            style="fill:#fff;fill-rule:evenodd"/>
                    </svg>
                </div>

                <h1 class="my-3 text-center text-[14px] text-slate-300">
                    <?php echo e($transaction->title); ?>

                </h1>

                <?php if(!$payed): ?>
                    <h1 class="my-3 text-center text-[21px] text-slate-300">Please, dont close this page</h1>
                <?php endif; ?>

                <?php if($payed): ?>
                    <h1 class="my-3 text-center text-[21px] text-green-500">PAYED</h1>
                <?php endif; ?>

                <section class=" my-5">
                    <div class="flex justify-between items-center">
                        <section>
                            <h1 class="text-slate-400 text-[13px]">TID:</h1>
                            <?php if(!$payed): ?>
                                <h1 class="text-slate-400 text-[13px]">Count:</h1>
                                <h1 class="text-slate-400 text-[13px]">Price:</h1>
                                <h1 class="text-slate-400 text-[13px]">TRC20:</h1>
                            <?php endif; ?>
                        </section>
                        <section class="space-y-1">
                            <h1 class="text-slate-400 text-[11px]"><?php echo e($transaction->getUUID()); ?></h1>
                            <?php if(!$payed): ?>
                                <h1 class="text-slate-400 text-[11px]"><?php echo e($transaction->count); ?></h1>
                                <h1 class="text-slate-400 text-[11px]"><?php echo e($transaction->amount); ?> $</h1>
                                <h1 class="text-slate-400 text-[10px]"><?php echo e(env('TRON_ADDRESS')); ?></h1>
                            <?php endif; ?>
                        </section>
                    </div>
                    <div class="flex justify-between items-center mt-5">
                        <?php if(!$payed): ?>
                            <h1 class="text-slate-400 text-[11px]">Commission: +3$</h1>
                            <div
                                x-data="{ tooltip: 'The commission is charged in connection with the Tether TRC20 commission (incoming + outgoing transfers)' }">
                                <svg x-tooltip="tooltip" xmlns="http://www.w3.org/2000/svg"
                                     class="icon icon-tabler icon-tabler-question-mark text-slate-400" width="16"
                                     height="16" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                     stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                    <path
                                        d="M8 8a3.5 3 0 0 1 3.5 -3h1a3.5 3 0 0 1 3.5 3a3 3 0 0 1 -2 3a3 4 0 0 0 -2 4"></path>
                                    <line x1="12" y1="19" x2="12" y2="19.01"></line>
                                </svg>
                            </div>
                        <?php endif; ?>
                    </div>
                </section>

                <?php if($payed): ?>
                    <div class="text-center my-6">
                        <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h1 class="text-slate-300 text-[13px]"><?php echo e($account); ?></h1>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>

                <?php if(!$payed): ?>
                    <form wire:submit.prevent="checkstart">
                        <div class="flex justify-center items-center">
                            <input type="text" placeholder="TXID (Transaction ID)" wire:model.defer="txid"
                                   class="py-2 px-3 bg-slate-700 border border-slate-700 rounded-xl text-slate-300 w-full"
                                   required>
                        </div>
                        <div class="flex justify-center items-center mt-3">
                            <button type="submit"
                                    class="cursor-pointer bg-blue-500 py-2 px-4 rounded-xl w-full duration-300 border border-blue-500 hover:bg-inherit text-slate-100">
                                Check
                            </button>
                        </div>
                    </form>

                    <?php if(env('TRON_TEST')): ?>
                        <button wire:click="testpay"
                                class="mt-4 cursor-pointer bg-blue-500 py-2 px-4 rounded-xl w-full duration-300 border border-blue-500 hover:bg-inherit text-slate-100">
                            Test
                        </button>
                    <?php endif; ?>
                <?php endif; ?>
            </figure>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\resources\views/livewire/pay/payeer.blade.php ENDPATH**/ ?>