<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <?php if(!isset($title)): ?>
        <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <?php else: ?>
        <title><?php echo e($title); ?></title>
    <?php endif; ?>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800&display=swap" rel="stylesheet">

    <link rel="icon" href="<?php echo e(asset('/favicon.ico')); ?>">

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <?php echo \Livewire\Livewire::styles(); ?>


</head>
<body class="font-sans bg-gray-900">
    <?php echo e($slot); ?>


    <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html>
<?php /**PATH C:\laragon\www\wavestore\resources\views/layouts/app.blade.php ENDPATH**/ ?>