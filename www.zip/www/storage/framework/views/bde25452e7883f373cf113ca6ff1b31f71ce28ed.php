<nav class="container flex items-center justify-center my-12">

    <ul class="flex items-center space-x-[100px]">
        <li>

            <?php if (isset($component)) { $__componentOriginalc334bdc6b763e4f24c7a61c38cb813a51d987a82 = $component; } ?>
<?php $component = App\View\Components\NavLink::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\NavLink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('welcome')),'class' => 'flex items-center space-x-3']); ?>

                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-home-2 text-sky-500" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                    <polyline points="5 12 3 12 12 3 21 12 19 12"></polyline>
                    <path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-7"></path>
                    <rect x="10" y="12" width="4" height="4"></rect>
                </svg>

                <span>Главная</span>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc334bdc6b763e4f24c7a61c38cb813a51d987a82)): ?>
<?php $component = $__componentOriginalc334bdc6b763e4f24c7a61c38cb813a51d987a82; ?>
<?php unset($__componentOriginalc334bdc6b763e4f24c7a61c38cb813a51d987a82); ?>
<?php endif; ?>

        </li>

        <li>

            <?php if (isset($component)) { $__componentOriginalc334bdc6b763e4f24c7a61c38cb813a51d987a82 = $component; } ?>
<?php $component = App\View\Components\NavLink::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\NavLink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('welcome1')),'class' => 'flex items-center space-x-3']); ?>

                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-blockquote text-sky-500" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                    <path d="M6 15h15"></path>
                    <path d="M21 19h-15"></path>
                    <path d="M15 11h6"></path>
                    <path d="M21 7h-6"></path>
                    <path d="M9 9h1a1 1 0 1 1 -1 1v-2.5a2 2 0 0 1 2 -2"></path>
                    <path d="M3 9h1a1 1 0 1 1 -1 1v-2.5a2 2 0 0 1 2 -2"></path>
                </svg>

                <span>Правила</span>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc334bdc6b763e4f24c7a61c38cb813a51d987a82)): ?>
<?php $component = $__componentOriginalc334bdc6b763e4f24c7a61c38cb813a51d987a82; ?>
<?php unset($__componentOriginalc334bdc6b763e4f24c7a61c38cb813a51d987a82); ?>
<?php endif; ?>

        </li>

        <li>

            <?php if (isset($component)) { $__componentOriginalc334bdc6b763e4f24c7a61c38cb813a51d987a82 = $component; } ?>
<?php $component = App\View\Components\NavLink::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\NavLink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('welcome1')),'class' => 'flex items-center space-x-3']); ?>

                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-help text-sky-500" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                    <circle cx="12" cy="12" r="9"></circle>
                    <line x1="12" y1="17" x2="12" y2="17.01"></line>
                    <path d="M12 13.5a1.5 1.5 0 0 1 1 -1.5a2.6 2.6 0 1 0 -3 -4"></path>
                </svg>

                <span>Как купить</span>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc334bdc6b763e4f24c7a61c38cb813a51d987a82)): ?>
<?php $component = $__componentOriginalc334bdc6b763e4f24c7a61c38cb813a51d987a82; ?>
<?php unset($__componentOriginalc334bdc6b763e4f24c7a61c38cb813a51d987a82); ?>
<?php endif; ?>

        </li>

        <li>

            <?php if (isset($component)) { $__componentOriginalc334bdc6b763e4f24c7a61c38cb813a51d987a82 = $component; } ?>
<?php $component = App\View\Components\NavLink::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\NavLink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('welcome1')),'class' => 'flex items-center space-x-3']); ?>

                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-lock-open text-sky-500" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                    <rect x="5" y="11" width="14" height="10" rx="2"></rect>
                    <circle cx="12" cy="16" r="1"></circle>
                    <path d="M8 11v-5a4 4 0 0 1 8 0"></path>
                </svg>

                <span>Активация ключей</span>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc334bdc6b763e4f24c7a61c38cb813a51d987a82)): ?>
<?php $component = $__componentOriginalc334bdc6b763e4f24c7a61c38cb813a51d987a82; ?>
<?php unset($__componentOriginalc334bdc6b763e4f24c7a61c38cb813a51d987a82); ?>
<?php endif; ?>

        </li>
    </ul>

</nav>
<?php /**PATH C:\laragon\www\wavestore\resources\views/components/navigation.blade.php ENDPATH**/ ?>