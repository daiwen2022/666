<section id="content" class="flex-1 mt-12 w-full mx-12 mb-10">

    <figure class="bg-slate-800 py-4 px-6 rounded-xl">

        <h2 class="text-slate-300 font-bold text-md mb-5">Total Users </h2>

        <section class="flex items-center space-x-5">

            <div class="rounded-full bg-sky-500 py-2 px-2 text-slate-100">
                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-users" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                    <circle cx="9" cy="7" r="4"></circle>
                    <path d="M3 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2"></path>
                    <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                    <path d="M21 21v-2a4 4 0 0 0 -3 -3.85"></path>
                </svg>
            </div>

            <span class="text-4xl text-slate-400"><?php echo e($usersCount); ?></span>

            <?php if($search != ''): ?>
                <span class="text-1xl opacity-75 text-slate-400">(<?php echo e($users->count()); ?> Founded)</span>
            <?php endif; ?>

        </section>

    </figure>


    <div class="mt-12">

        <div class="overflow-x-auto relative">
            <div class="flex justify-between">
                <div class="my-3">
                    <input type="text" name="search" placeholder="Search..." wire:model="search" class="bg-slate-700 rounded-xl py-2 px-4 outline-none border border-slate-700 duration-300 focus:bg-inherit text-slate-300">
                </div>
            </div>
            <table class="w-full text-sm text-left text-gray-400">
                <thead class="text-xs uppercase bg-gray-700 text-gray-400">
                <tr>
                    <th scope="col" class="py-3 px-6">
                        ID
                    </th>
                    <th scope="col" class="py-3 px-6">
                        Name
                    </th>
                    <th scope="col" class="py-3 px-6">
                        EMAIL
                    </th>
                    <th scope="col" class="py-3 px-6">
                        ADMIN
                    </th>
                    <th scope="col" class="py-3 px-6">
                        Created at
                    </th>
                    <th scope="col"></th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="border-b bg-gray-800 border-gray-700">
                        <th scope="row" class="py-4 px-6 font-medium text-sky-400 whitespace-nowrap">
                            <?php echo e($user->id); ?>

                        </th>
                        <td class="py-4 px-6">
                            <?php echo e($user->name); ?>

                        </td>
                        <td class="py-4 px-6">
                            <?php echo e($user->email); ?>

                        </td>
                        <td class="py-4 px-6">
                            <?php if($user->isAdmin()): ?>
                                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-circle-check text-green-400" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                    <circle cx="12" cy="12" r="9"></circle>
                                    <path d="M9 12l2 2l4 -4"></path>
                                </svg>
                            <?php else: ?>
                                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-circle-minus text-red-400" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                    <circle cx="12" cy="12" r="9"></circle>
                                    <line x1="9" y1="12" x2="15" y2="12"></line>
                                </svg>
                            <?php endif; ?>
                        </td>
                        <td class="py-4 px-6">
                            <?php echo e($user->created_at->toFormattedDateString()); ?>

                        </td>
                        <td class="py-4 px-6 space-x-2 flex items-center">

                            <button wire:click="edit(<?php echo e($user); ?>)" class="cursor-pointer">
                                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-pencil" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                    <path d="M4 20h4l10.5 -10.5a1.5 1.5 0 0 0 -4 -4l-10.5 10.5v4"></path>
                                    <line x1="13.5" y1="6.5" x2="17.5" y2="10.5"></line>
                                </svg>
                            </button>

                            <button wire:click="delete(<?php echo e($user); ?>)" class="cursor-pointer">
                                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-x" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                    <line x1="18" y1="6" x2="6" y2="18"></line>
                                    <line x1="6" y1="6" x2="18" y2="18"></line>
                                </svg>
                            </button>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr class="bg-gray-800">
                            <td colspan="6" class="py-4 px-6 font-medium">
                                <div class="flex justify-center items-center">
                                    <span class="text-2xl opacity-75">No users found...</span>
                                </div>
                            </td>
                        </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if(!is_null($editing)): ?>
            <form wire:submit.prevent="save">
                <?php if (isset($component)) { $__componentOriginalc80673fa66aa0e990fa942c532b32f33e9543e87 = $component; } ?>
<?php $component = App\View\Components\Modal\Dialog::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal.dialog'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal\Dialog::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model.defer' => 'showEditModal']); ?>
                     <?php $__env->slot('title', null, []); ?> Edit user <?php $__env->endSlot(); ?>
                     <?php $__env->slot('content', null, []); ?> 



                        <?php if (isset($component)) { $__componentOriginal897ff558ef59e5b6b49218ff56fe3f7bd49c347b = $component; } ?>
<?php $component = App\View\Components\InputGroup::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InputGroup::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'name','label' => 'Name','error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('editing.name'))]); ?>
                            <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = App\View\Components\Input::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Input::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','wire:model' => 'editing.name','id' => 'name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal897ff558ef59e5b6b49218ff56fe3f7bd49c347b)): ?>
<?php $component = $__componentOriginal897ff558ef59e5b6b49218ff56fe3f7bd49c347b; ?>
<?php unset($__componentOriginal897ff558ef59e5b6b49218ff56fe3f7bd49c347b); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginal897ff558ef59e5b6b49218ff56fe3f7bd49c347b = $component; } ?>
<?php $component = App\View\Components\InputGroup::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InputGroup::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'email','label' => 'EMAIL','error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('editing.email'))]); ?>
                            <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = App\View\Components\Input::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Input::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'email','wire:model' => 'editing.email','id' => 'email']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal897ff558ef59e5b6b49218ff56fe3f7bd49c347b)): ?>
<?php $component = $__componentOriginal897ff558ef59e5b6b49218ff56fe3f7bd49c347b; ?>
<?php unset($__componentOriginal897ff558ef59e5b6b49218ff56fe3f7bd49c347b); ?>
<?php endif; ?>

                        <div class="text-center my-3">
                            <button wire:click="toggleAdmin" class="py-2 px-4 rounded-xl bg-gray-900 text-white w-full">TOGGLE ADMIN</button>
                        </div>
                     <?php $__env->endSlot(); ?>
                     <?php $__env->slot('footer', null, []); ?> 
                        <div class="space-x-3">
                            <button wire:click="$toggle('showEditModal')" class="bg-red-500 px-3 py-2 text-white rounded-xl">Cancel</button>
                            <button type="submit" class="bg-gray-900 px-3 py-2 text-white rounded-xl">Save</button>
                        </div>
                     <?php $__env->endSlot(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc80673fa66aa0e990fa942c532b32f33e9543e87)): ?>
<?php $component = $__componentOriginalc80673fa66aa0e990fa942c532b32f33e9543e87; ?>
<?php unset($__componentOriginalc80673fa66aa0e990fa942c532b32f33e9543e87); ?>
<?php endif; ?>
            </form>
        <?php endif; ?>

    </div>

</section>
<?php /**PATH C:\laragon\www\wavestore\resources\views/livewire/dash/users.blade.php ENDPATH**/ ?>