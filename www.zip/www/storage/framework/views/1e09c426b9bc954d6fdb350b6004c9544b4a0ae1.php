<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="bgs__video w-auto h-auto overflow-hidden fixed z-[-999] left-0 right-0 top-0 bottom-0" style="opacity: 1;">
        <video id="bgvideo" class="bgvideo w-auto h-auto min-w-[100%] min-h-[100%] border-[0] opacity-[0.3]" poster="https://i.imgur.com/ODpemDt.jpg" loop="" autoplay="" muted="" playsinline="">
            <source src="https://bsteam.clan.su/filesbg/animatebg.mp4" type="video/mp4">
        </video>
    </div>

     <?php $__env->slot('title', null, []); ?> WAVESTORE | Магазин аккаунтов <?php $__env->endSlot(); ?>

    <header>
        <?php if (isset($component)) { $__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e = $component; } ?>
<?php $component = App\View\Components\Navigation::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Navigation::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e)): ?>
<?php $component = $__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e; ?>
<?php unset($__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e); ?>
<?php endif; ?>
    </header>

    <main class="mt-[70px]">
        <div class="hero">
            <div class="container text-center">

                <div class="flex justify-center mb-[50px]">
                    <img src="<?php echo e(asset('favicon.svg')); ?>" class="h-28" alt="favicon">
                </div>

                <h1 class="text-slate-200 font-semibold text-5xl">Популярный магазин VPN и других товаров</h1>
                <p class="text-slate-400 mt-4">WAVESTORE - это популярный магазин аккаунтов самых различных товаров</p>

            </div>
        </div>

        <div class="container mt-12">
            <section class="flex items-center justify-center gap-12">
                <a href="/" class="flex items-center space-x-6 bg-slate-800 py-2 pr-6 pl-5 rounded-xl duration-300 border border-slate-800 hover:bg-transparent hover:border-slate-600">
                    <img src="https://ruju.ru/bitrix/templates/aspro_next/images/telegram-logo-2.png" class="h-16 rounded-full" alt="">
                    <div>
                        <h1 class="font-medium text-slate-200 text-[18px]">Тех. Поддержка</h1>
                        <p class="text-slate-400 text-[17px]">Вопросы по магазину</p>
                    </div>
                </a>

                <a href="/" class="flex items-center space-x-6 bg-slate-800 py-2 pr-6 pl-5 rounded-xl duration-300 border border-slate-800 hover:bg-transparent hover:border-slate-600">
                    <img src="https://ruju.ru/bitrix/templates/aspro_next/images/telegram-logo-2.png" class="h-16 rounded-full" alt="">
                    <div>
                        <h1 class="font-medium text-slate-200 text-[18px]">Telegram канал</h1>
                        <p class="text-slate-400 text-[17px]">Акции и скидки</p>
                    </div>
                </a>
            </section>
        </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\wavestore\resources\views/welcome.blade.php ENDPATH**/ ?>